<?php

class Usuario {
    private $_id;
    private $_nombre_completo;
    private $_mail;
    private $_pass;
    private $_reservacion;
    private $_rol;

    public function __construct($id, $nombre_completo, $mail, $pass, $reservacion, $rol) {
        $this->setId($id);
        $this->setNombreCompleto($nombre_completo);
        $this->setEmail($mail);
        $this->setPassword($pass);
        $this->setReservacion($reservacion);
        $this->setRol($rol);
    }

    public function getId() {
        return $this->_id;
    }

    public function setId($id) {
        $this->_id = $id;
    }

    public function getNombreCompleto() {
        return $this->_nombre_completo;
    }

    public function setNombreCompleto($nombre_completo) {
        $this->_nombre_completo = $nombre_completo;
    }

    public function getEmail() {
        return $this->_mail;
    }

    public function setEmail($mail) {
        $this->_mail = $mail;
    }

    public function getPassword() {
        return $this->_pass;
    }

    public function setPassword($pass) {
        $this->_pass = ($pass);
    }

    public function getReservacion() {
        return $this->_reservacion;
    }

    public function setReservacion($reservacion) {
        $this->_reservacion = ($reservacion);
    }

    public function getRol() {
        return $this->_rol;
    }

    public function setRol($rol) {
        $this->_rol = ($rol);
    }

    public function returnJson() {
        $usuario = array();

        $usuario["id"] = $this->getId();
        $usuario["nombre_completo"] = $this->getNombreCompleto();
        $usuario["mail"] = $this->getEmail();
        $usuario["pass"] = $this->getPassword();
        $usuario["reservacion"] = $this->getReservacion();
        $usuario["rol"] = $this->getRol();

        echo json_encode($usuario);
    }
    
}

?>