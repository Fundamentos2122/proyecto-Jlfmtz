
document.addEventListener("DOMContentLoaded", function() {
    document.addEventListener("click", muestra_oculta);
});

function muestra_oculta(zona) {
    if (document.getElementById) {
      //se obtiene el id
      var list = document.getElementById(zona); //se define la variable "el" igual a nuestro div
      list.style.display = list.style.display == "none" ? "block" : "none"; //damos un atributo display:none que oculta el div
    }
}