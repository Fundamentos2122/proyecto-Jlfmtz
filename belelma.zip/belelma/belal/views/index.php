<?php include("header.php"); ?>

<div class="container">
    <div class="row py-3">
        <div class="col-12 col-lg-6">
            <div class="row">
                <?php
                    include("../../models/DB.php");
                    include("../../admin/models/Paquete.php");

                    try {
                        $connection = DBConnection::getConnection();
                    }
                    catch(PDOException $e) {
                        error_log("Error de conexion - " . $e, 0);

                        exit();
                    }

                    if ($_SERVER["REQUEST_METHOD"] == "GET") {
                        //Leer
                        //Traer el listado de todos los registros
                        try {
                            $query = $connection->prepare("SELECT * FROM paquetes");
                            $query->execute();

                            while($row = $query->fetch(PDO::FETCH_ASSOC)) {
                                $paquete = new Paquete($row["id"], $row["nombre_paquete"], $row["huespedes"], $row["habitaciones"], $row["detalles"], $row["precio"], $row["foto"]);

                                echo 
                                    "<div class='col-6'>".
                                        "<img src=\"data:image/jpeg;base64," . $paquete->getFoto() . "\" class='img-fluid card'>".
                                    "</div>".
                                    "<div class='col-6'>".
                                        "<h5>" . $paquete->getNombrePaquete() . "</h5>".
                                        "<p>" . $paquete->getHuespedes() . 'Huespedes / ' . $paquete->getHabitaciones() . " Habitaciones</p>".
                                        "<p>" . $paquete->getDetalles() . "</p>".
                                        "<p class='text-right'>$" . $paquete->getPrecio() . "/noche</p>".
                
                                        "<form action='../../controllers/reservarController.php' method='POST'>".
                                            "<input type='hidden' name='_method' value='PUT'>".
                                            "<input type='hidden' name='paquete_id' value=". $paquete->getId() .">".    
                                            "<input type='submit' value='Reservar' class='btn btn-block btn-success'>".
                                        "</form>".
                                    "</div>";
                            }
                        }
                        catch(PDOException $e) {
                            error_log("Error en query - " . $e, 0);

                            exit();
                        }
                    }
                ?>
            </div>
        </div>
        
    </div>
</div>

<?php include("footer.php"); ?>


