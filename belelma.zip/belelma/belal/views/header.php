<?php
    //Verificar al usuario
    session_start();

    if (!array_key_exists("mail", $_SESSION)) {
        header("Location: http://localhost/belelma/views/login.php");
        exit();
    }

    $id_reservacion = $_SESSION["reservacion"];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fundamentos2122.github.io/framework-css-Jlfmtz/css/framework.css">
    <link rel="stylesheet" href="../../css/styles.css">
    <title>Document</title>
</head>
<body>
    <div class="header-belal">
        <nav class="navbar">
            <a href="" class="navbar-brand">BELAL</a>
            <button class="navbar-toggle" type="button">
                -
            </button>
            
            <div class="navbar-collapse">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="index.php" class="nav-link">
                            Inicio
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php
                            echo
                                "<a class='nav-link' href='reservaciones.php?id=" . $id_reservacion . "'>Reservaciones</a>";
                        ?>
                    </li>
                    <li class="nav-item">
                        <a href="../../views/logout.php" class="nav-link">Cerrar sesión</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>