<?php include("header.php"); ?>

<div class="container">
    <div class="py-3">
    <?php
        include("../../models/DB.php");
        include("../../admin/models/Paquete.php");

        try {
            $connection = DBConnection::getConnection();
        }
        catch(PDOException $e) {
            error_log("Error de conexion - " . $e, 0);

            exit();
        }
        if ($_SERVER["REQUEST_METHOD"] == "GET") {
            //Leer
            if (array_key_exists("id", $_GET)) {
                //Traer la información de un elemento        
                $id = $_GET["id"];
        
                try {
                    $query = $connection->prepare("SELECT * FROM paquetes WHERE id = :id");
                    $query->bindParam(":id", $id, PDO::PARAM_INT);
                    $query->execute();
        
                    while($row = $query->fetch(PDO::FETCH_ASSOC)) {
                        $paquete = new Paquete($row["id"], $row["nombre_paquete"], $row["huespedes"], $row["habitaciones"], $row["detalles"], $row["precio"], $row["foto"]);
    
                        echo 
    
                            "<div class='col-12 my-3'>".
                                "<h5>" . $paquete->getNombrePaquete() . "</h5>".
                                "<p>" . $paquete->getHuespedes() . 'Huespedes / ' . $paquete->getHabitaciones() . " Habitaciones</p>".
                                "<p>" . $paquete->getDetalles() . "</p>".
                                "<p class='text-right'>$" . $paquete->getPrecio() . "/noche</p>".
        
                                "<form action='../../controllers/reservarController.php' method='POST'>".
                                    "<input type='hidden' name='_method' value='DELETE'>".  
                                    "<input type='submit' value='Cancelar' class='btn btn-block btn-danger'>".
                                "</form>".
                            "</div>";
                    }
                }
                catch(PDOException $e) {
                    error_log("Error en query - " . $e, 0);
                    header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
                    exit();
                }
            }
        }
    ?>
        
    </div>
</div>

<?php include("footer.php"); ?>