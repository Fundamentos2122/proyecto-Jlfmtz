<?php

include("../models/DB.php");
include("../admin/models/Evento.php");

try {
    $connection = DBConnection::getConnection();
}
catch(PDOException $e) {
    error_log("Error de conexion - " . $e, 0);

    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    //Leer
    //Traer el listado de todos los registros
    try {
        $query = $connection->prepare("SELECT * FROM eventos");
        $query->execute();

        while($row = $query->fetch(PDO::FETCH_ASSOC)) {
            $evento = new Evento($row["id"], $row["foto"], $row["url_evento"]);

            echo 
                "<div class='col-4'>".
                    "<a href=" . $evento->getUrlEvento() . ">".
                        "<img src=\"data:image/jpeg;base64," . $evento->getFoto() . "\" class='img-fluid card'>".
                        "<p>" . $evento->getNombreEvento() . "</p>".
                    "</a>".
                "</div>";
        }
    }
    catch(PDOException $e) {
        error_log("Error en query - " . $e, 0);

        exit();
    }
}
?>