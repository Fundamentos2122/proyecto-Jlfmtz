<?php

include("../models/DB.php");
include("../models/Usuario.php");
include("../admin/models/Paquete.php");

try {
    $connection = DBConnection::getConnection();
}
catch(PDOException $e) {
    error_log("Error de conexion - " . $e, 0);
    header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($_POST["_method"] == "PUT") {
        //Actualizar
        session_start();
        $id_user = $_SESSION["id"];
        $id_paquete = $_POST["paquete_id"];
        
        try {
            $query = $connection->prepare('UPDATE usuarios SET reservacion = :reservacion WHERE id = :id');
            $query->bindParam(':id', $id_user, PDO::PARAM_INT);
            $query->bindParam(':reservacion', $id_paquete, PDO::PARAM_INT);
            $query->execute();

            if ($query->rowCount() == 0) {
                //Error

                exit();
            }

            header("Location: http://localhost/belelma/belal/");
        }

        catch(PDOException $e) {
            error_log("Error en query - " . $e, 0);
            header("Location: http://localhost/belelma/views/error.php?error=Error en query.");
            exit();
        }
    }
    else if ($_POST["_method"] == "DELETE") {
        //Eliminar
        session_start();
        $id_user = $_SESSION["id"];
        
        try {
            $query = $connection->prepare('UPDATE usuarios SET reservacion = NULL WHERE id = :id');
            $query->bindParam(':id', $id_user, PDO::PARAM_INT);
            $query->execute();

            if ($query->rowCount() == 0) {
                //Error

                exit();
            }

            header("Location: http://localhost/belelma/belal/");
        }

        catch(PDOException $e) {
            error_log("Error en query - " . $e, 0);
            header("Location: http://localhost/belelma/views/error.php?error=Error en query.");
            exit();
        }
           
    }
    else {
        //Error
    }
}

?>