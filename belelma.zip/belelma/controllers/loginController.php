<?php

include("../models/DB.php");
include("../models/Usuario.php");

try {
    $connection = DBConnection::getConnection();
}
catch(PDOException $e) {
    error_log("Error de conexión - " . $e, 0);

    header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
    exit();
}

if($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($_POST["_method"] == "POST") {
        //Login
        $mail = $_POST["mail"];
        $pass = $_POST["pass"];
        

        try {
            $query = $connection->prepare('SELECT * FROM usuarios WHERE mail = :mail AND pass = :pass');
            $query->bindParam(':mail', $mail, PDO::PARAM_STR);
            $query->bindParam(':pass', $pass, PDO::PARAM_STR);
            $query->execute();

            if($query->rowCount() == 0) {
                //No se encontro al usuario
                header("Location: http://localhost/belelma/views/login.php?error=Usuario y/o contraseña invalida");
                exit();
            }

            $usuario;

            while($row = $query->fetch(PDO::FETCH_ASSOC)) {
                
                $usuario = new Usuario($row["id"], $row["nombre_completo"], $row["mail"], $row["pass"], $row["reservacion"], $row["rol"]);

            }

            session_start();
            
            $_SESSION["id"] = $usuario->getId();
            $_SESSION["nombre_completo"] = $usuario->getNombreCompleto();
            $_SESSION["mail"] = $usuario->getEmail();
            $_SESSION["reservacion"] = $usuario->getReservacion();
            $_SESSION["rol"] = $usuario->getRol();

            if($_SESSION["rol"] !== "administrador") {
                header("Location: http://localhost/belelma/belal/views/");
            }
            else {
                header("Location: http://localhost/belelma/admin/");
            }

            
        }
        catch(PDOException $e) {
            error_log("Error de conexión - " . $e, 0);
            header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
            exit();
        }
    }
}

?>