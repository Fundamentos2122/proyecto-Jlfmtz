<?php

include("../models/DB.php");
include("../models/Usuario.php");

try {
    $connection = DBConnection::getConnection();
}
catch(PDOException $e) {
    error_log("Error de conexion - " . $e, 0);
    header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    //Leer
    if (array_key_exists("id", $_GET)) {
        //Traer la información de un elemento        
        $id = $_GET["id"];

        try {
            $query = $connection->prepare("SELECT * FROM usuarios WHERE id = :id");
            $query->bindParam(":id", $id, PDO::PARAM_INT);
            $query->execute();

            while($row = $query->fetch(PDO::FETCH_ASSOC)) {
                $usuario = new Usuario($row["id"], $row["nombre_completo"], $row["mail"]);

                $usuario->returnJson();
            }
        }
        catch(PDOException $e) {
            error_log("Error en query - " . $e, 0);

            exit();
        }
    }
    else {
        //Traer el listado de todos los registros
        try {
            $query = $connection->prepare("SELECT * FROM usuarios");
            $query->execute();

            while($row = $query->fetch(PDO::FETCH_ASSOC)) {
                $usuario = new Usuario($row["id"], $row["nombre_completo"], $row["mail"]);

                //echo 
                    //imprimir usuarios
            }
        }
        catch(PDOException $e) {
            error_log("Error en query - " . $e, 0);
            header("Location: http://localhost/belelma/views/error.php?error=Error en query.");
            exit();
        }
    }
}
elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($_POST["_method"] == "POST") {
        //Guardar
        $nombre_completo = $_POST["nombre_completo"];
        $mail = $_POST["mail"];
        $pass = $_POST["pass"];
        //$passHash = password_hash($pass, PASSWORD_BCRYPT);
        $rol = "normal";

        try {
            $query = $connection->prepare('INSERT INTO usuarios VALUES(NULL, :nombre_completo, :mail, :pass, NULL, :rol)');
            $query->bindParam(':nombre_completo', $nombre_completo, PDO::PARAM_STR);
            $query->bindParam(':mail', $mail, PDO::PARAM_STR);
            $query->bindParam(':pass', $pass, PDO::PARAM_STR);
            $query->bindParam(':rol', $rol, PDO::PARAM_STR);
            $query->execute();

            if ($query->rowCount() == 0) {
                //Error

                exit();
            }

            header("Location: http://localhost/belelma/belal/views/");
        }
        catch(PDOException $e) {
            error_log("Error en query - " . $e, 0);
            header("Location: http://localhost/belelma/views/error.php?error=Error en query.");
            exit();
        }
    }
    else if ($_POST["_method"] == "PUT") {
        //Actualizar
    }
    else if ($_POST["_method"] == "DELETE") {
        //Eliminar
    }
    else {
        //Error
    }
}

?>