<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Santa Catarina</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">En una acta levantada el 1º de julio  de 1617 en Rioverde consta que el padre Fr. Juan Bautista de Mollinedo, habiendo celebrado la misa, cogió del altar una cruz portátil, la levantó en alto con sus manos en señal de posesión para poner, de parte dicha provincia de San Pedro y San Pablo de Michoacán, a los religiosos que administraban a los indios los Santos Sacramentos " y a la dicha Iglesia le puso el nombre de Santa Catarina Mártir" y que tomaba y que "Aprehendía posesión jurídica y derecho parroquial de dicha Iglesia y Convento y Parroquia" y fijó su jurisdicción.


</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Volcán de los Panales, Paisaje de Padú de San Antonio, Paisaje de Los Cachorros, Paisaje de La Mano Poderosa, Paisaje de El Pie de Cristo, Paisaje de El Manantial de los Anteojos.
<br>

        </div>
        <div class="col-6">
            <img src="https://scontent.fslp1-1.fna.fbcdn.net/v/t39.30808-6/p180x540/261913609_398916471970249_7313820893155097371_n.jpg?_nc_cat=109&ccb=1-5&_nc_sid=8bfeb9&_nc_eui2=AeHBqYFcCUKAtVtXoE2OMEgxJ49xRpc0Tw8nj3FGlzRPD8U4xF155WLagIHHlw_FKhbu1GeOvxVP22Adg7FsaNFN&_nc_ohc=dFq1Dj_0YNgAX_eKq6d&_nc_ht=scontent.fslp1-1.fna&oh=a370f9adaa097f30f90fb9c665f0567d&oe=61B88E01">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>