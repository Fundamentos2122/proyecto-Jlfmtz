<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Ebano</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">Se refiere que las ruinas arqueológicas de Ébano corresponden al pueblo Huasteco de "Tamatao". En el idioma huasteco las raíces son TAM= a lugar de y ATA=casa, lo que nos da "lugar de casa", nombre con el cual se le denomina durante el siglo XVI. Las fiestas populares se presentan el 18 de marzo y se celebra la fiesta conmemorativa petrolera. Se tiene como tradición celebrar el 21 de junio el Aniversario del Municipio Libre y el 31 de junio la Feria Tradicional.

</p>
           
            <p class="jsutify-content mt-3">Ébano es el lugar donde brotó en 1904 el primer pozo petrolero del país, originando la fiebre petrolera en México.
Como atractivos turísticos cuenta con: Laguna del Pez, Dique Leal, Plaza del Río Pánuco, Cerro de Pemex, Gruta de la Cueva Grande, Zona de Riego Pujal-Coy, que es la más grande de América Latina


<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://lh6.googleusercontent.com/-ng66zmzkCek/V2M6V1Rur_I/AAAAAAAAKSo/LuRmMeVQYJAhJBHzCSQbfsXNFvBq5J3hQCJkC/photo.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29548.483737579543!2d-98.39785011665798!3d22.218804042602013!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d7ce1d402d6913%3A0xbba76a47d60dcf60!2sEbano%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177541432!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>