<?php include("header.php"); ?>

<div class="container">
    <div class="mt-5">
        <div class="row">
            <div class="col-6">
                <img src="https://visitasanluispotosi.com/wp-content/uploads/2019/06/Portada_Tamul.jpg" alt="" class="img-fluid card">
            </div>
            <div class="col-6">
                <h3 class="my-4">Aquismón</h3>
                <p class="text-justify mb-3"> es una de las poblaciones más importantes de la región de la Huasteca Potosina. Se localiza a aproximadamente 45 kilómetros al norte de Xilitla y a 55 kilómetros al sur de Ciudad Valles, y desde aquí se puede iniciar una increíble aventura para descubrir algunas de las maravillas culturales y naturales más sorprendentes del estado de San Luis Potosí.</p>
                <hr>
            </div>
        </div>
    </div>

    <div class="mt-5">
        <div class="row">
            <div class="col-6">
                <img src="https://www.eluniversal.com.mx/sites/default/files/2019/07/24/real_de_catorce_pueblo.jpg" alt="" class="img-fluid card">
            </div>
            <div class="col-6">
                <h3 class="my-4">Real de Catorce</h3>
                <p class="text-justify mb-3">El Pueblo Mágico de Real de Catorce es un viejo real de minas, ubicado en la región del Altiplano, fundado alrededor de 1778 y que alcanzó su época de mayor esplendor a finales del siglo XVIII. En nuestros días está convertido en uno de los mayores atractivos turísticos de San Luis Potosí.</p>
                <hr>
            </div>
        </div>
    </div>

    <div class="mt-5">
        <div class="row">
            <div class="col-6">
                <img src="https://visitasanluispotosi.com/wp-content/uploads/2019/06/Portada_STM_2.jpg" alt="" class="img-fluid card">
            </div>
            <div class="col-6">
                <h3 class="my-4">Santa María del Río</h3>
                <p class="text-justify mb-3">“Cuna del rebozo” y fundado en 1542, el recién nombrado Pueblo Mágico el primero de diciembre del 2020, Santa María del Río es uno de los municipios de mayor tradición en el estado gracias a la producción de estas telas desde la época prehispánica. Además, está a sólo 20 minutos de la ciudad de San Luis Potosí, por lo que te será muy sencillo visitarlo durante tu estancia.</p>
                <hr>
            </div>
        </div>
    </div>

    <div class="mt-5">
        <div class="row">
            <div class="col-6">
                <img src="https://visitasanluispotosi.com/wp-content/uploads/2020/05/Xilitla4.jpg" alt="" class="img-fluid card">
            </div>
            <div class="col-6">
                <h3 class="my-4">Xilitla</h3>
                <p class="text-justify mb-3">Xilitla es un pueblo con arraigadas tradiciones ancestrales de los nativos nahuas y teenek, quienes conviven en armonía con la naturaleza y la modernidad. Está enclavado en una porción montañosa de la Huasteca, y por su ubicación y ambiente prodigioso, de inmediato hechiza al visitante. Para entender esto hay que verlo, hay que sentirlo, hay que recorrer sus calles empinadas, visitar sus atractivos, dejarse abrazar por la niebla, que en ciertas épocas cubre el entorno.</p>
                <hr>
            </div>
        </div>
    </div>
    
</div>

<?php include("footer.php"); ?>