<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Lagunillas</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">El nombre de Lagunillas deriva de que cerca de la cabecera se encuentran, o al menos se encontraban en el siglo XVII numerosas lagunas chicas. En el año de 1830 la Legislatura del Estado decretó la "Ley sobre arreglos de Municipios" y en el artículo 16 se refiere a la Villa de Lagunillas como cabecera del mismo nombre. Las fiestas populares se presentan el 13 de junio y se lleva a cabo la festividad en honor a San Antonio de Padua. 
Se tiene como tradición efectuar el 24 de diciembre una fiesta con baile y feria.


</p>
           
            <p class="jsutify-content mt-3">Como atracción turística cuenta con: Las Culebras, conjunto de cráteres de distintos tamaños que forman un racimo, Laguna Redonda, con verdes aguas que nunca se agotan y cerca de ahí en el fondo de un arroyo yace una gran roca con una abertura de la que sale constantemente una corriente subterránea de aire frío, la llaman La Piedra Zumbadora, Laguna Colorada, Laguna de Pastores.
A un lado del poblado de San Rafael existe un núcleo de ruinas arqueológicas, son cientos de montículos, algunos piramidales, diseminados en una extensa área.



<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://i2.wp.com/www.turimexico.com/wp-content/uploads/2015/06/lagunillas.jpg?w=640&ssl=1">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14839.929386032094!2d-99.57516278194748!3d21.586612173981543!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d44ab52839508d%3A0x3b364dbc12946116!2s79780%20Lagunillas%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177706964!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>