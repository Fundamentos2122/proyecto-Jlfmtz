<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Villa de Reyes</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">La hoy ciudad de Villa de Reyes se llamó en sus primitivos orígenes del siglo XVI, simplemente sitio del Valle de San Francisco, sucedió que los misioneros se adelantaron con sus trabajos de evangelización cristiana a los conquistadores que pretendían someter a los naturales por medio de las armas y para el caso fundaron varios fuertes en distintos lugares del gran tunal, a estos establecimientos militares se les llamó presidios. Esto es: Pre=Antes y Sitium=Sitio, es decir: antes del asentamiento de alguna población.


</p>
           
            <p class="jsutify-content mt-3">Las fiestas populares se presentan del 20 al 25 del mes de diciembre y se lleva a cabo la Feria, Corrida de Toros y las Fiestas Navideñas.
Fiesta al Santo Patrono San Francisco de Asís el 4 de octubre
Feria anual del 22 al 26 de septiembre. Como atracción turística se encuentra: El Centro Vacacional Gogorrón.  La antigua hacienda de don Pedro Gogorrón, construida a fines del siglo XVI, llegó a tener 17 pozos, una hidroeléctrica y una fabrica textil. La hacienda de la Ventilla de la misma época que la anterior, constituyen uno de los más hermosos cascos que afortunadamente se conserva en buen estado. La ex-hacienda de Bledos, Calderón, Jesús María y Boca de Santiago. Sus presas como: La Providencia, Plan De San Luis, Golondrinas, Cabras, Dolores, De Jesús, San Vicente, Boca de Santiago, La Laguna de Arriba y la de Abajo.
 


<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://www.elsoldesanluis.com.mx/incoming/wp5iv3-villa-de-reyes.jpg/ALTERNATES/LANDSCAPE_1140/villa-de-reyes.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d59266.23339437935!2d-100.9703529483673!3d21.813536994878103!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x842ac1a6259587eb%3A0xfa67a16b73e15ed0!2s79500%20Villa%20de%20Reyes%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639178367221!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>