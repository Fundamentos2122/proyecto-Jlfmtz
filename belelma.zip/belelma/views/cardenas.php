<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Cárdenas</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">En el siglo XVII ya se encontraban misiones, rancherías y haciendas siendo la principal  por su enormidad la Ciénega de San Nicolás, la cual fue fundada por Luis de Cárdenas cuya merced se la concedió el Marquéz de Guadalcázar en 1613. De allí el  nombre que conocemos en la actualidad.
</p>
           
            <p class="jsutify-content mt-3">Las fiestas populares se presentan el 9 de septiembre, celebrándose  la festividad en honor de San Nicolás Tolentino, Patrono del lugar, por lo que llega una peregrinación con gentes del lugar que residen en otros estados de la república. Como atracción turística se encuentra: Río Canoas, que riega al municipio formando varios depósitos naturales llamados pozas, Presas Nápoles, El Naranjo e Higinio Olivo, Casco de la Ex Hacienda Ciénega de San Nicolás de Cárdenas. 
<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://i0.wp.com/www.turimexico.com/wp-content/uploads/2015/06/cardenas.jpg?fit=600%2C450&ssl=1">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29594.447552719965!2d-99.65716991692648!3d21.999585411739375!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d596635a599e91%3A0x66e39a26d0b483c3!2sC%C3%A1rdenas%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639176997921!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>