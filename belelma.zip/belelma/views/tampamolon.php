<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Tampamolón Corona</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">Antiguo pueblo huasteco, nombre indígena que significa Tam-Pam-Olon=lugar de muchos jabaliés. 
En el decreto Núm. 61 del 8 de octubre de 1827 en el artículo 28 se le da la categoría de municipio. Las fiestas populares se presentan el 24 y 25 de julio y se lleva a cabo la festividad en honor de Santiago Apóstol.


</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra ruinas arqueológicas a ambos lados del río en los Ranchos de La Bolsa, El Palmar y la comunidad de Yohuala.
<br>

        </div>
        <div class="col-6">
            <img src="https://scontent.fslp1-1.fna.fbcdn.net/v/t1.18169-9/226368_428436203866782_1397581561_n.jpg?_nc_cat=104&ccb=1-5&_nc_sid=09cbfe&_nc_eui2=AeHXGPN572e90nEouJsslmvtAJoNuY5PnjYAmg25jk-eNjPXEDljRQIw1XjkBIrbmb08xgxYN8tCzcwNtJoeSI1E&_nc_ohc=5WAizjvv9IsAX8bvOdM&_nc_ht=scontent.fslp1-1.fna&oh=59c8f034790e96e70d55caa2932dd7ab&oe=61D83D5E">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>