<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fundamentos2122.github.io/framework-css-Jlfmtz/css/framework.css">
    <link rel="stylesheet" href="../css/styles.css">
    <title>Document</title>
</head>
<body>
    <nav class="navbar">
        <a href="" class="navbar-brand">BELELMA</a>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-7 mt-5">
                <h1 class="text-danger">ERROR!</h1>
                <div class="h4">
                    <?php
                        if(array_key_exists("error", $_GET)){
                            echo $_GET["error"];
                        }
                        else {
                            header("Location: http://localhost/belelma/views/");
                        }
                    ?>
                </div>
                <a href="index.php" class="btn btn-primary mt-5">Regresar a la página de inicio</a>
            </div>
            <div class="col-5">
                <img src="../img/error.svg" alt="" class="img-fluid">
            </div>
        </div>
    </div>
    
    
</body>
</html>