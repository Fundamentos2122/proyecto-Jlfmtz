<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Villa de Ramos</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">Se atribuye a Fr. Jerónimo de Pangua el haber intervenido en la fundación del pueblo. Era el año de 1608, andando Juan Salayandia Vizcaíno, con dos hijos suyos mulatos corriendo yeguas cimarronas por el valle que hoy se llama de Ramos, aconteció que uno de ellos se aparea a cierto menester y escarbando, tomo unas piedras que  parecían metales. En Zacatecas, a donde las llevaron, las enseñaron a algunos mineros, que vinieron luego a conocer la veta. Por parecerles cosa de poca importancia, se volvieron todos, excepto Domingo Montero y su mujer, que con sus descubridores siguieron buscando y dieron con cuatro vetas ricas y a la voz del descubrimiento acudieron mineros de diferentes partes y personas ricas, tomaron todos partes de las minas y fue haciéndose la población. Por haberse descubierto el mineral en Domingo de Ramos, se dio ese nombre al pueblo.
En la década de 1870 se comenzó a explotar la primera mina del mineral de la Paz, por lo que la actividad minera se fue acrecentando, por el nombre de esta mina se conoció así a este centro mineral y después a todo el municipio. 


</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Pequeño poblado de La Hedionda, donde se han encontrado gigantescos huesos y en los alrededores de La Ciénega, lascas de pedernal. Yoliat, en donde vienen todos los años Los Huicholes a celebrar de manera simbólica a los espíritus de sus antepasados. Hernández, San Rafael y Salitral de Carrera, donde se han encontrado vestigios arqueológicos. La Mina. El Calvario.


<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2d/Parroquia_de_San_Juan_Nepomuceno.jpg/800px-Parroquia_de_San_Juan_Nepomuceno.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29418.588149487943!2d-101.92582311589648!3d22.827517247867643!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86818464c0cfca93%3A0x61e49b6cb21a1553!2s78690%20Villa%20de%20Ramos%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639178460347!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
</div>

<?php include("footer.php"); ?>