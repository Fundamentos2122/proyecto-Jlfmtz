<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Villa de Arriaga</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">Se dice que la historia del municipio de Villa de Arriaga está íntimamente ligada a la historia de la hacienda de Gallinas, que en el año de 1685 era propiedad de don Antonio Maldonado Zapata, y dentro de esta se formó una congregación la cual se denominó como "El Gallo" que a principios del siglo XVII fue como un Oasis para los romeros en sus peregrinaciones, y posteriormente sería "Villa de Arriaga", en honor del Benemérito del Estado don Ponciano Arriaga de acuerdo al decreto Núm. 63 promulgado el 7 de mayo de 1874.

</p>
           
            <p class="jsutify-content mt-3">Las fiestas populares se presentan del 2 al 12 de diciembre y se lleva a cabo la festividad en honor a la Virgen de Guadalupe.  Del 15 al 17 de septiembre, fiestas patrias de Independencia. Como atracción turística se encuentra: Ex Hacienda de Santiago, con hermosos patios coloniales, rodeados de arquerías.  El casco de esta Ex Hacienda se encuentra en muy buen estado y tiene una fábrica de mezcal. Ex Hacienda de San Francisco. Ex Hacienda de El Tepetate. Ex Hacienda Puerto Espino. Ex Hacienda Gallinas. Ex Hacienda Santa Lucía. Ex Hacienda Las Pulgas.


<br>

        </div>
        <div class="col-6">
            <img src="https://elexpres.com/images_news/fb8ce2villa-de-arriaga.jpeg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>