<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Vanegas</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">Seguramente el nombre de este municipio lo toma de la Hacienda San Juan de Banegas ya desde mediados del siglo pasado el nombre se escribió generalmente como Vanegas, cambiando solamente la letra inicial y parece que en aquella época era muy frecuente alterar los nombres y los apellidos por la común ignorancia que había, lo cierto es que se escribió de uno y de otro modo indistintamente. 

</p>
           
            <p class="jsutify-content mt-3">Las fiestas populares se presentan el 24 de junio, celebrándose a San Juan y del 10 al 15 de junio la feria regional. Como atracción turística se encuentra: Manantial de agua cristalina y termal. Cerro de Guanache. Grutas Los Riscos.


<br>

        </div>
        <div class="col-6">
            <img src="https://www.elsoldesanluis.com.mx/incoming/eytuyc-5187cd25-458c-4e61-861a-e29fbb687a1b.jfif/alternates/LANDSCAPE_400/5187cd25-458c-4e61-861a-e29fbb687a1b.jfif">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>