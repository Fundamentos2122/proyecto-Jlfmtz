<?php include("header.php"); ?>

<div class="container">
    <div class="mt-5">
        <div class="row">
            <div class="col-6">
                <img src="https://visitasanluispotosi.com/wp-content/uploads/2019/01/slp-nota-cascada-tamul-4.jpg" alt="" class="img-fluid card">
            </div>
            <div class="col-6">
                <h3 class="my-4">Cascada de Tamul</h3>
                <p class="text-justify mb-3">localizada en el municipio de Aquismón, en la región de la Huasteca, es considerada por muchos “la joya de las cascadas potosinas”.</p>
                <hr>
                <p class="text-justify mt-3">La mejor temporada para visitar la Cascada de Tamul es de octubre a mayo</p>
            </div>
        </div>
    </div>

    <div class="mt-5">
        <div class="row">
            <div class="col-6">
                <img src="https://visitasanluispotosi.com/wp-content/uploads/2019/01/slp-nota-jardin-surrealista-edward-james-xilitla-1.jpg" alt="" class="img-fluid card">
            </div>
            <div class="col-6">
                <h3 class="my-4">Jardín Surrealista</h3>
                <p class="text-justify mb-3">Conocido también como “Las Pozas”, el Jardín Surrealista de Edward James fue creado por la mente creativa de este poeta y artista inglés, en el corazón del Pueblo Mágico de Xilitla, al sureste de San Luis Potosí.</p>
                <hr>
                <p class="text-justify mt-3">-Horario: lunes a domingo, de 9:00 a 18:00 hrs.</p>
                <p class="text-justify">-Entrada: Adultos $70, niños menores de 6 años, jubilados $35.</p>
                <p class="text-justify">-Guía Turística: $200 español, $250 inglés y francés. El recorrido dura aproximadamente 1 hora 15 mins.</p>
                <p class="text-justify">-Cuenta con servicio de restaurante.</p>
            </div>
        </div>
    </div>

    <div class="mt-5">
        <div class="row">
            <div class="col-6">
                <img src="https://visitasanluispotosi.com/wp-content/uploads/2019/01/slp-nota-jardin-surrealista-edward-james-xilitla-1.jpg" alt="" class="img-fluid card">
            </div>
            <div class="col-6">
                <h3 class="my-4">La Media Luna</h3>
                <p class="text-justify mb-3">La Laguna de la Media Luna, fantástico parque estatal ideal para organizar días de campo y disfrutar de la naturaleza en compañía de los amigos o de la familia, se localiza a solo 3 kilómetros al suroeste de Rioverde.</p>
                <hr>
                <p class="text-justify mt-3">El Parque Estatal Laguna de la Media Luna cuenta con toda la infraestructura necesaria para pernoctar y acampar en un ambiente de completamente seguro y familiar.</p>
            </div>
        </div>
    </div>
    
</div>

<?php include("footer.php"); ?>