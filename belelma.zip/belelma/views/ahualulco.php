<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Ahualulco</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">La ciudad de Ahualulco antiguo pueblo Yahualulco, palabra azteca que significa rodeo grande, compuesto de Yahually, corona o ruedo y Ulco, grande o rincón.</p>
            <p class="jsutify-content mt-3">Las fiestas populares se presentan del 26 de febrero al 2 de marzo y se lleva a cabo la festividad en honor de La Candelaria, organizándose feria popular, corridas de toros y peleas de gallos.</p>
            <p class="jsutify-content mt-3">Como atracción turística se encuentra:
Cañón de Ahualulco, con las formaciones rocosas del Cerrito de Rojas.<br>
Presa de Santa Genoveva, que es una de las más grandes del estado.</p>
        </div>
        <div class="col-12 col-lg-6">
            <img src="https://sanluis.eluniversal.com.mx/sites/default/files/2021/04/10/101_slp.jpeg" alt="" class="img-fluid">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>