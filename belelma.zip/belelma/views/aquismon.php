<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Aquismón</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">El término Aquismón, tiene tres interpretaciones: se dice que significa en Huasteco "árbol al pie de un pozo", y el autor Salvador Penilla López lo describe como "pozo limpio con la coa", finalmente el historiador Joaquín Meade nos dice que significa "lugar de conchas en un pozo".</p>
            <p class="jsutify-content mt-3">Como atracción turística se encuentra:
        
Cascada de Tamúl, que es la más alta del estado con 105 mts. de altura, Ciénega de Tanchachín, en la que se puede navegar en bote y ofrece buenos lugares para la caza y la pesca.  Además cuenta con una fauna abundante y el Sótano de las Golondrinas, sima de aproximadamente 300 mts. de profundidad, en su interior se encuentra un túnel cuyo recorrido máximo ha sido de 4 km. 

<br>
        </div>
        <div class="col-12 col-lg-6">
            <img src="https://www.gob.mx/cms/uploads/article/main_image/85296/Aquismon-Cascada-Tamul-web.jpg" alt="" class="img-fluid">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14836.276662699338!2d-99.02765588193691!3d21.62222831876725!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d67d4e154ecf83%3A0xae153fe9584ce02d!2s79760%20Aquism%C3%B3n%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639176818777!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>