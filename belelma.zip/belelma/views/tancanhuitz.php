<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Tancanhuitz de Santos</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">Nombre huasteco se le atribuyen diversos significados Tancanhuitz = "Lugar de flores", "Canoa de flores amarillas". Las fiestas populares se presentan del 25 al 29 de septiembre y se lleva a cabo la festividad en honor a San Miguel Arcángel, Semana Santa y Todos Santos, además de todas las fechas cívicas históricas que componen el calendario.
Actualmente existen grupos y organizaciones que promueven el rescate y la preservación de las actividades culturales de los grupos indígenas. 

</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Río Coy, Presa La Herradura, Cueva de Los Brujos, e Iglesia de los 149 Escalones.

<br>

        </div>
        <div class="col-6">
            <img src="https://live.staticflickr.com/3069/2471464607_8836ecf3e0_b.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>