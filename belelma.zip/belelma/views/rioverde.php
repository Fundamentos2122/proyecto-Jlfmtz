<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Rioverde</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">Se dice que ya en la época colonial el nombre de Rioverde fue dado a la región por un personaje llamado Xicachalchimitl, indio descendiente de los reyes de Texcoco. La fundación de Rioverde fue hecha el día 1º de julio de 1617 por orden de Fr. Juan Bautista Mollinedo con categoría de Misión. Posteriormente se le llamó "La Pastora". 
Finalmente en el decreto Núm. 60 del 5 de octubre de 1827 se le da la categoría de Ciudad a Rioverde hasta la fecha.


</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Laguna de La Media Luna, que mide aproximadamente 300 metros de largo y 60 metros de ancho. Sus aguas son muy transparentes y se puede practicar el buceo, Ex Hacienda de Guadalupe de Cieneguillas, donde existe la enorme gruta de la Iglesia Vieja o La Catedral, con un salón de gigantescas proporciones, cuajado de estalactitas y estalagmitas. Es tan espectacular y grande, que cabría en su recinto la Catedral Potosina, Grutas del Ángel, Balneario de aguas termales, ubicado en el Rancho de San Diego, Hacienda de Don Diego, con su extensa presa y sus yacimientos de calcedonia, Manantiales, Represa, Ojo Caliente, Anteojos, Palma Larga, Las Cascaditas, Los Peroles, Poza Azul, La Planta, Hacienda de Jabalí.

<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://pulsoslp.com.mx/images/tnfocus/0/0/696/423/2020/10/17/lamedialuna.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d59224.85208138699!2d-100.01742319788089!3d21.913272525775003!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d50cac0d4d405b%3A0xf6d6cb8fcffc17df!2sRioverde%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639178004835!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>