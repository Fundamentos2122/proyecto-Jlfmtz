<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Villa de Guadalupe</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">El territorio donde ahora se asienta el municipio de Villa de Guadalupe fue ocupado en la época prehispánica por las tribus salvajes llamadas Negritos los cuales fueron combatidos por los conquistadores españoles en el siglo XVI. En el año de 1772 aparece como dueño de estas tierras Francisco de Vallejo y más tarde en 1780 José Joaquín de Solís y Felipe Coronado. Al correr del tiempo y al margen de las vastas propiedades agrícolas, se fundaron dos congregaciones con los nombres de Represadero y la Biznaga, fue en aumento el número de habitantes y en 1857 fue declarada Villa, con el nombre de Villa Ixtle, habiéndolo cambiado más adelante por el de Villa de Guadalupe; su fundador fue don Francisco Villanueva durante el gobierno del general Eulalio Degollado; en 1857 y hasta principios de este siglo encerraba dentro de sus límites las haciendas de Solís, La Presa y la Presita.

</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Ojo de Agua de San Bartolo. Manantial de aguas termales Magdalena.


<br>

        </div>
        <div class="col-6">
            <img src="https://scontent.fslp1-1.fna.fbcdn.net/v/t1.6435-9/56162105_2362083870492746_2608760051803881472_n.jpg?_nc_cat=110&ccb=1-5&_nc_sid=09cbfe&_nc_eui2=AeGBvebeWecNaKlQDnZ0Ch0YoZtkAygDQyShm2QDKANDJFDlHJYvgSuDH9eR-9K66zJvcTxmcMMTqmFbUyDOwgVK&_nc_ohc=YuOuLTAeLkcAX8fd0S1&_nc_ht=scontent.fslp1-1.fna&oh=4f6c0ed88f33af72cbfe7744a58bfeee&oe=61D855E7">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>