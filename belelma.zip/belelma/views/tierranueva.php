<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Tierra Nueva</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">El territorio donde hoy se asienta el municipio de Tierranueva esta ubicado en la cuenca del Río Verde, la que los geógrafos señalan como región media del Estado, refieren los historiadores que en el siglo XVI vivieron los salvajes chichimecas, pero se señala que su fundación fue en el siglo XVIII. El 12 de abril de 1712 Olorís, alcalde mayor de San Luis Potosí le da el nombre de San Nicolás de Tierranueva Río de Jofre, nombre original con categoría de pueblo pero con Ayuntamiento. 

</p>
           
            <p class="jsutify-content mt-3">Las fiestas populares se presentan del 1º al 10 de septiembre y se lleva a cabo la festividad en honor a San Nicolás, con feria, corridas de toros, charreadas y bailes.
Se tiene como tradición realizar Danzas de Aztecas, Sonajeros y La Pluma. Como atracción turística se encuentra: Presa de la Muñeca, lugar en donde se puede practicar la motonáutica, la navegación en lanchas de motor y la pesca deportiva. Lienzo Charro. Iglesia del Santuario, en honor del Sagrado Corazón de Jesús.


<br>

        </div>
        <div class="col-6">
            <img src="https://scontent.fslp1-1.fna.fbcdn.net/v/t39.30808-6/244339167_4343529969094918_9067838303566052816_n.jpg?_nc_cat=111&ccb=1-5&_nc_sid=8bfeb9&_nc_eui2=AeFkOG8gsURboPgvmMYqjOqZLNUQwm-iqCws1RDCb6KoLBh6c5Mn452ruxs8FXtyXNatTuhPmjhhE_ZlFJuP2p6v&_nc_ohc=FYCGubuCo2sAX_qCz5B&_nc_ht=scontent.fslp1-1.fna&oh=9f54c374d28ceb08082d31563cb4314d&oe=61B7959C">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>