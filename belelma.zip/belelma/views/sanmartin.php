<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita San Martín Chauchicuautla</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">La palabra Chalchicuautla tiene raíces aztecas que quieren decir: Chalchihuitl=esmeralda sin pulir y Tlán=abundancia. Por otra parte el escritor Gutierre Tibón en su libro El jade de México, dice "Puede referirse a los Chalchihuites que se encontraban y se encuentran en las corrientes", efectivamente el municipio se haya regado por numerosos arroyos.
La antigua denominación de esta población fue la de "Martín y Luis" nombre del jefe o jefes fundadores, por lo que con el tiempo el nombre quedó como "San Martín Chalchicuautla"






</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Pozo de Agua Ahuetla, La Lajita, una laja de 150 metros de una sola pieza, Poza Huatulco, Ruinas del Centro Ceremonial de Cosapa.
<br>

        </div>
        <div class="col-6">
            <img src="https://scontent.fslp1-1.fna.fbcdn.net/v/t1.6435-9/42568581_2287351101551049_2700826893451526144_n.jpg?_nc_cat=105&ccb=1-5&_nc_sid=730e14&_nc_eui2=AeGB3WihLs2ycvU93-Fv3EkfnMI8bTJl1oecwjxtMmXWh0hxSQ1YvdbJNyv9jDMVkb0g0DiDrM38Zos8wRfT1h-f&_nc_ohc=o7GPcWe03HMAX9I_DQ1&_nc_ht=scontent.fslp1-1.fna&oh=00_AT87_JPsRhjhYf7LLksjWG_mexKA9jX1IIRAyIxoq_kDcQ&oe=61D87327">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>