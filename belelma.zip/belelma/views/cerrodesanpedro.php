<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Cerro de San Pedro</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">Un huachichil fue quien encontró la gran riqueza del mineral y quien lo comunicó al capitán Caldera y este a su vez lo informó para el descubrimiento del mineral a Gregorio de León, a Juan de la Torre y Pedro de Anda; este último bautizó el lugar con el nombre de San Pedro del Potosí, en honor del santo de su nombre y en memoria de las famosas minas del Potosí, en Bolivia. Las fiestas populares se presentan el 29 de junio y se lleva a cabo la festividad en honor de San Pedro.
</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Iglesia del Señor de San Pedro, que cuenta con una capilla dedicada a San Jerónimo, con un pequeño pero muy elaborado retablo barroco. Los Tiros de la Mina de San Pedro y Ex Hacienda "La Parroquia".



<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://www.elsoldesanluis.com.mx/incoming/lcz2vb-cerro-de-san-pedro-8.jpg/ALTERNATES/LANDSCAPE_1140/Cerro%20de%20San%20Pedro%208.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7387.288194556274!2d-100.8049671279931!3d22.2156278739071!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86801d58804645a9%3A0x1866edce19e84c7a!2sCerro%20de%20San%20Pedro%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177216175!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>