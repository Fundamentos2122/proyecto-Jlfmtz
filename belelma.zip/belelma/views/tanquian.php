<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Tanquián de Escobedo</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">Este nombre, en idioma huasteco quiere decir "Lugar de Palmas", la población actual esta edificada sobre las ruinas del antiguo pueblo que allí existió en la época prehispánica. La legislatura del Estado dictó su decreto Núm. 53 promulgado el 29 de octubre de 1870 en el cual se le da la categoría de municipio a Tanquian. 
Escobedo es en honor al general Mariano Escobedo, Gobernador del Estado de San Luis Potosí.

</p>
           
            <p class="jsutify-content mt-3">	Las fiestas populares se presentan el 19 de marzo y se celebra la fiesta religiosa patronal en honor a San José.
Se tiene como tradición realizar los días sábado un tianguis, el día 2 de noviembre la fiesta del día de muertos y en la fiesta patronal hacer danzas de Malinche, Xochitines y Las Varitas. Como atracción turística se encuentra: Río Moctezuma, que forma lagos como El Tecolote, El Mezquite y  Unión. Zona arqueológica. Playa del Maguey.

<br>

        </div>
        <div class="col-6">
            <img src="https://scontent.fslp1-1.fna.fbcdn.net/v/t31.18172-8/21273135_710752902467977_8750019915466676709_o.jpg?_nc_cat=109&ccb=1-5&_nc_sid=e3f864&_nc_eui2=AeEV5QdrZh70Oy20Z4VMAHljHcriXPy_HpcdyuJc_L8el8HF5aBV44w-ZhFryXuLEZWFKXHK6GzfarcK3gZ4NfRg&_nc_ohc=PyJzI2CoTpgAX_OkU_F&_nc_ht=scontent.fslp1-1.fna&oh=f6c33f6fa346e941d6c4c2df66ea9e87&oe=61D70051">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>