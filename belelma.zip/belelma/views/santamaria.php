<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Santa María del Río</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">La fecha de fundación y el origen del nombre resulta confuso y controvertido pues hay dos períodos distintos: En uno, el más antiguo, nos refiere que hubo bautismo de cuachichiles (o guachichiles) en el año de 1542 el día de la Asunción de la Virgen y que bajo esta advocación se concedió fundar el pueblo al que el Virrey don Luis de Velazco llamó Santa María del Río. Las fiestas populares se presentan del 1º al 15 de agosto y se lleva a cabo la festividad en honor de la Asunción de la Virgen.  En esta fiesta se celebra la feria nacional del rebozo.


</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Manantial de Lourdes, Manantial de aguas termales Ojo Caliente, Ex Hacienda Labor del Río, Ex Hacienda Villela, Ex Hacienda Santo Domingo, Ex Hacienda El Fuerte, Ex Hacienda Pozo del Carmen.
<br>

        </div>
        <div class="col-6">
            <img src="https://i1.wp.com/massanluis.com/uploadsMSL/2020/03/24444676462_2be6021896.jpg?w=499&ssl=1">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>