<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Tampacán</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">El nombre de este municipio es de indudable origen huasteco Tampacan cuyas raíces son: Tam=lugar y Pacan=cimientos, lo que nos da el primitivo significado de "Lugar de cimientos". El 14 de diciembre de 1861 el Congreso del Estado dictó su decreto número 4 por medio del cual se le da la categoría de municipio.

</p>
           
            <p class="jsutify-content mt-3">Las fiestas populares se presentan el 15 de agosto y es en honor de la Asunción de la Virgen.
Se tiene como tradición realizar procesiones religiosas, tianguis y las danzas de Las Varitas, Rebozo y Xochitines.

<br>

        </div>
        <div class="col-6">
            <img src="https://scontent.fslp1-1.fna.fbcdn.net/v/t1.6435-9/104191308_596832621257447_3382281190916019043_n.jpg?_nc_cat=111&ccb=1-5&_nc_sid=09cbfe&_nc_eui2=AeG-QyCS2EjaqvsOVtwVzPw-XajUo6TOmh9dqNSjpM6aH60xisCpcOYelXBQzVcEn8qYpJxxzxpAPL3U51X-v9s3&_nc_ohc=K8L8HYwfyBAAX-tRlOD&_nc_ht=scontent.fslp1-1.fna&oh=261f9fa3180a7716ba18a8a66d5d37e2&oe=61DADAD5">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>