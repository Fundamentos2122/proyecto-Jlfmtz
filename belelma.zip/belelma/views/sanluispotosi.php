<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita San Luis Potosí</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">El 3 de noviembre de 1592 fue fundado el "Pueblo de San Luis Mesquitique" en el lugar donde en el año de 1583 Fr. Diego de la Magdalena había congregado a unos indios guachichiles, los cuales llegaron al territorio potosino en el siglo XIII D.C.
El nombre de San Luis es en honor de San Luis IX Rey de Francia; posteriormente el Virrey don Francisco Fernández de la Cueva Duque de Alburquerque concedió que de Pueblo y Minas del Potosí se constituyera a la categoría de ciudad el 30 de mayo de 1656. Cambiando el nombre de Mesquitique por el de Potosí, en referencia a la riqueza de las minas del Cerro de San Pedro comparadas con las minas del Potosí en Bolivia.





</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Centro Cultural y Recreativo Tangamanga, Museo Regional Potosino, Museo Nacional de la Máscara, Museo de Arte Popular, Casa Manuel José Othón, Catedral, Templo de El Carmen, Templo de San Agustín, Palacio de Cristal, Instituto Potosino de Bellas Artes, Plaza España, Plaza de El Carmen, Jardín Cristóbal Colón, Histórica Calzada de Nuestra Señora de Guadalupe.
<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://media-cdn.tripadvisor.com/media/photo-s/11/16/77/07/de-paseo-por-el-centro.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d236565.8117209385!2d-101.0961584616468!3d22.112977923671213!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x842aa20005acfb79%3A0xed2ee29afe18257!2sSan%20Luis%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639178177868!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>