<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Santo Domingo</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">El territorio donde ahora se encuentra asentado el municipio de Santo Domingo fue habitado en la antigüedad por cuachichiles (o guachichiles) en el siglo XIII D.C. Las crónicas y antiguas referencias no registran ninguna penetración de misioneros religiosos en el siglo XVI. Fue hasta mediados del siglo XVII cuando aquí se trazaron los linderos de 2 enormes haciendas la de sierra Hermosa y la de Illescas, que es donde actualmente está ubicado el municipio de Santo Domingo. Su fundador fue don Ignacio Colunga Dávila quien se asegura promovió la erección del municipio en 1857.

</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Lagunas de Agua Salada, como la de Santo Domingo y el Barreal de Santa Clara. Antigua Hacienda de Illescas. Cerro del Sabino. 
<br>

        </div>
        <div class="col-6">
            <img src="http://www.inafed.gob.mx/work/enciclopedia/EMM24sanluispotosi/municipios/24033/24t033-02.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>