<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita San Vicente Tancuayalab</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">La palabra huasteca Tancuayalab significa lugar del bastón de mando, indica también que aquí residía el gran sacerdote, por lo que se supone debió ser sin duda un notable centro ceremonial. Se conoció primeramente con el nombre de San Francisco Tancuayalab, porque fue fundado por misioneros franciscanos en el siglo XVI. Posteriormente el pueblo se cambió de lugar y en el año de 1767 se estableció en el sitio donde se encuentra actualmente con el nombre de San Vicente Tancuayalab, cerca del río Moctezuma.

</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: En la cabecera municipal una pequeña iglesia, donde se venera a la Virgen de Guadalupe y otra de mayor tamaño dedicada a San Francisco de Asís. Río Moctezuma, que es límite con el estado de Veracruz. Ruinas arqueológicas de San Francisco Cuayalab.
<br>

        </div>
        <div class="col-6">
            <img src="https://mapio.net/images-p/23224319.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>