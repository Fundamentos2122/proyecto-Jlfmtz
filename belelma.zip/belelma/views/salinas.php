<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Salinas</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">Se dice que Juan de Tolosa, asentó su real al pie de la Bufa de Zacatecas el 8 de septiembre de 1596. Se le llama el conquistador, fundador y poblador de "Salinas del Peñón Blanco". El nombre de Salinas deriva de las salineras que se localizan en el lugar. Se dice que los indígenas de esta región rendían tributo con sal a los emperadores Aztecas
Se tiene como tradición celebrar el primer viernes de marzo una fiesta, en la cual se cuenta con exposición de artes típicas de la región, carreras de caballos, peleas de gallos, juegos pirotécnicos, música, bailes y feria popular. También es característico el combate de flores y las danzas de Chichimecas y La Pluma. 6 de marzo, fiesta tradicional.



</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Cerro del Peñón Blanco, Laguna de Azogueros, Lago El Estanque, Lago Santa María, Lago La Hedionda, Lago El Salitral, Casa Grande y La Muralla, de la Compañía Salinas de México, S.A.
<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://visitasanluispotosi.com/wp-content/uploads/2020/12/Salinas2.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29463.06634666267!2d-101.72999606615767!3d22.62083291444195!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8681be263a2239f7%3A0xf49bf5c50240c97e!2sSalinas%20de%20Hidalgo%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639178047822!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>