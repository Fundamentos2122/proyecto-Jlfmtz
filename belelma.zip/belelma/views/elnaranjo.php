<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita El Naranjo</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">El nombre de "El Naranjo" surgió a raíz de una planta de Naranjo que  se encontraba a un costado de un camino vecinal el cuál se dirigía al municipio de Ciudad del Maíz, mismo que servía de referencia para los pobladores que en su trayectoria lo usaban para descansar y seguir su camino en busca de víveres. Actualmente es el Bulevar.

</p>
           
            <p class="jsutify-content mt-3">En el municipio de El Naranjo, se encuentran varios maravillosos lugares, en los que se encuentran, las cascadas de Minas Viejas, El Meco y El Naranjo. 
 


<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://www.turimexico.com/wp-content/uploads/2015/06/elnaranjo.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29483.271503175147!2d-99.34290011627616!3d22.52634899472066!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x867f4e014e29e31d%3A0xf9dfabd7a274a785!2sEl%20Naranjo%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177573854!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>