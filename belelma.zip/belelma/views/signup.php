<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fundamentos2122.github.io/framework-css-Jlfmtz/css/framework.css">
    <link rel="stylesheet" href="../css/styles.css">
    <title>Document</title>
</head>
<body>
    <div class="head-log">
        <a href="index.php">
            <h3>BELELMA</h3>
        </a>
    </div>

    <div class="bg-dark login">
        <h2 class="text-center text-light pt-2">Belal</h2>
        <h5 class="text-center text-light">Registrate</h5>

        <div class="container">
            <form action="../controllers/usuariosController.php" method="post" class="row" autocomplete="off">
                <input type="hidden" name="_method" value="POST">
                <div class="col-12 text-center form-group">
                    <input type="text" name="nombre_completo" placeholder="Nombre" required>
                </div>   
                <div class="col-12 text-center form-group">
                    <input type="email" name="mail" placeholder="Correo electrónico" required>
                </div>
                <div class="col-12 text-center form-group">
                    <input type="password" name="pass" placeholder="Contraseña" required>
                </div>
                <div class="col-12 form-group text-center">
                    <input type="submit" value="Ingresar" class="btn btn-success" required> 
                </div>
            </form>
        </div>
        <div class="text-center py-4">
            <a href="login.php" class="link-registro">¿Ya tienes cuenta?</a>
        </div>
        
        
    </div>
</body>
</html>