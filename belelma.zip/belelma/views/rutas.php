<?php include("header.php"); ?>

<div class="container">
    <h2 class="text-center mt-3">¡Conoce las rutas de San Luis Potosí!</h2>
    <div class="text-center img-hr"></div>
    <p class="my-3">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Minima, nulla omnis quidem voluptatibus quisquam quaerat ad consequatur. Nulla ab saepe blanditiis sint mollitia quos aspernatur tenetur sunt? Asperiores, officia possimus?</p>

    <div class="ruta-1 py-5 px-5">
        <div class="row">
            <div class="col-12 col-lg-6">
                <img src="https://visitasanluispotosi.com/wp-content/uploads/2021/08/Salud1-700x467.jpg" class="img-fluid card">
            </div>
            <div class="col-12 col-lg-6">
                <h3 class="mt-2">Cinco días</h3>
                <p>Un imperdible semana</p>
                <p>Día uno: San Luis Potosí da la bienvenida.</p>
                <P>Día dos: El segundo día de aventura en San Luis Potosí inicia con un traslado a Tamasopo.</P>
                <p>Día tres: Para el tercer día, se parte muy temprano para el poblado de Tanchachín.</p>
                <p>Día cuatro: Iniciar el día de camino al Castillo de la Salud en el Municipio de Axtla de Terrazas.</p>
                <p>Día cinco: Xilitla es el próximo punto a visitar.</p>
                <hr class="my-3">
                
                <a href="https://goo.gl/maps/gf3RZwP9cv2jPL1h8" target="_blank" class="btn btn-primary">Conoce la ruta</a>
            </div>
        </div>
    </div>

    <div class="ruta-2 py-5 px-5">
        <div class="row">
            <div class="col-12 col-lg-6">
                <h3 class="mt-5">El Salado</h3>
                <p>Dejate sorprender por el Altiplano potosino</p>
                <hr class="my-3">

                <a href="https://goo.gl/maps/EsT7vpzz2GUMSUCJ6" target="_blank" class="btn btn-primary">Conoce la ruta</a>
            </div>

            <div class="col-12 col-lg-6">
                <img src="../img/slp-nota-real-de-catorce-3-700x467.jpg" class="img-fluid card">
            </div>
        </div>
    </div>

    <div class="ruta-3 py-5 px-5">
        <div class="row">
            <div class="col-12 col-lg-6">
                <img src="../img/slp-nota-ruta-mezcal-1.jpg" class="img-fluid card">
            </div>
            <div class="col-12 col-lg-6">
                <h3 class="mt-5">Ruta del Mezcal</h3>
                <p>Recorre la ruta y disfruta la bebida de los Dioses</p>
                <hr class="my-3">

                <a href="https://goo.gl/maps/qHw2w1SHf8eSCw6WA" target="_blank" class="btn btn-primary">Conoce la ruta</a>
            </div>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>