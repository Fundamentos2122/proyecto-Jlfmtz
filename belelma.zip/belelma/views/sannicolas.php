<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita San Nicolás Tolentino</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">La fundación del pueblo de San Nicolás Tolentino se supone que se formó hacia el año 1600. Se nos refiere que los libros parroquiales no están completos y los datos que se encuentran datan de la mitad del siglo XVII. Se dice que los fundadores fueron indios chichimecas. Lo que sí consta documentalmente es que en el año 1673 ya tenía iglesia. Las fiestas populares se presentan el 10 de diciembre y se lleva a cabo la festividad en honor a San Nicolás Tolentino. Se tiene como tradición celebrar el 10 de diciembre la fiesta de San Nicolás Tolentino, misma en donde se realiza carreras de caballos, peleas de gallos, jaripeos, danzas, bailes y fuegos artificiales.






</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Cañada de Aguacatal, con acantilados y peligrosas grutas, Ex Hacienda de Santa Catarina, Laguna de Santo Domingo, lugar donde se encuentra la presa Las Golondrinas, en la cual se practica la pesca deportiva.
<br>

        </div>
        <div class="col-6">
            <img src="https://i.pinimg.com/originals/db/d2/9d/dbd29d9f2f2a613bd6384f069de14558.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>