<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Tamuín</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">En diferentes épocas el nombre actual de Tamuín lo han escrito de diferentes maneras: Tamui, Tamuche, Tamuchi, Tam-Ohin, Tamo-Oxxi, Tam-Huinic, Tamuyn, Tamohi, Tamnoc, y la significación también ha sido diferente se dice que: "Lugar de Catán", "Lugar de mosquitos" y otra versión nos dice que Tam-Huinic que su traducción es "Lugar del libro del saber".Lo que nos refiere que fue el centro ceremonial más importante de toda la huasteca. En el año de 1793 el religioso franciscano Fr. Cristóbal Herrera Alcorcha, en su informe sobre las misiones lo describe como el "Santuario de Tamud o Tamuín". 


</p>
           
            <p class="jsutify-content mt-3">Las fiestas populares se presentan en Semana Santa. Como atracción turística se encuentra: Pirámides de Tantoc, dos moles geométricas que parecen asomarse entre los naranjales. Pirámide cuadrangular, localizada en Tzintzin-Tajub. Balneario Taninúl. Río Tamuín.
El Balneario de Taninul: Es un balneario muy acreditado. Se encuentra ubicado en el municipio de Tamuín, muy inmediato al límite con el municipio de  Valles,  S. L. P. El balneario  y  el hotel allí construido,  atrae centenares de turistas  nacionales y  extranjeros por sus manantiales sulfurosos.

<br>

        </div>
        <div class="col-6">
            <img src="https://media-cdn.tripadvisor.com/media/photo-s/1b/4e/72/21/tamuin.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>