<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Venado</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">Refieren los historiadores que según los escritos de los religiosos del siglo XVI que el territorio donde ahora se asienta el municipio de Venado fue habitado por dos grupos: los guachichiles en la parte sur y en el norte los llamados negritos. Se dice que el primer Fraile doctrinero que estuvo en la región fue Fr. Diego de la Magdalena en el año de 1554. En ese entonces se le dio el nombre de "San Sebastián del Agua del Venado". Las fiestas populares se presentan del 1º al 8 de diciembre y se lleva a cabo la festividad en honor a La Purísima Concepción.  El día 08 se realiza feria popular, música y Danza de Matlachines.

</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Parroquia del pueblo, levantada por los Franciscanos.  Es un edificio con una hermosa y alta torre y un frontispicio neoclásico en arenisca rosa. Capilla de San Diego. Capilla de San Cayetano. Capilla del Señor de las Injurias. Antigua Hacienda de Guanamé. Manantial El Sauco. Acueducto. Los Siete Callejones. Balneario Ojo de Agua.


<br>

        </div>
        <div class="col-6">
            <img src="https://i1.wp.com/www.turimexico.com/wp-content/uploads/2015/06/venado.jpg?w=500&ssl=1">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>