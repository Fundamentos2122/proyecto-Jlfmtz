<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Matlapa</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">El nombre de Matlapa deriva del náhuatl Matlaltl=Lugar de Redes. Nos refieren  que en épocas pasadas en los tiempos de lluvias se formaban alrededor de lo que hoy es el municipio numerosas redes de agua que provenían de los cerros dejando a la vista un hermoso espectáculo. 
Se considera una versión más que dice: que el nombre de Matlapa, viene de "Matlepoxtle" sierra que se encuentra entre los límites de Matlapa y la comunidad de Atlamáxatl a una distancia aproximada de 3 kilómetros del centro del poblado. Matlepoxtlé; quiere decir "Mano de Hierro".



</p>
           
            <p class="jsutify-content mt-3">Las fiestas patronales se llevan a cabo el 29 de junio en honor a San Pedro Apóstol. Se celebra cada año la Municipalización de Matlapa del 26 de diciembre al 1º de enero. Fiesta de Xantolo los días 1,2 y 3 de noviembre. En la localidad de Chalchitepetl cada año en el mes de agosto se celebra una fiesta tradicional en la cual le "Danzan al Agua" toda la noche con cantos nahuas. Como atracción turística se encuentra el río Tancuilín el cual ofrece a los turistas un bello paisaje además de que por no contar con aguas profundas se presta para nadar.
 


<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://scontent.fslp1-1.fna.fbcdn.net/v/t1.6435-9/57649022_1544757415654348_1326271495684489216_n.jpg?_nc_cat=101&ccb=1-5&_nc_sid=8bfeb9&_nc_eui2=AeF6aBseCgra1jYbybEh_Huf1nmJ4iGSUZ3WeYniIZJRnf7Y6XtaFw7ILKN307UbDbOWYqAvf4BAuSqdm6yYG3Dy&_nc_ohc=NmEWcSJ-IuUAX-3NHUp&tn=aEkqfZzvAaeNwh40&_nc_ht=scontent.fslp1-1.fna&oh=d8cc9a80f4b35891eeb893e27abed52a&oe=61D8555F">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29730.868006825232!2d-98.84249331772031!3d21.336350017689906!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d6933d21e18e8d%3A0xf2317ef9f1130af4!2sMatlapa%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177784366!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>