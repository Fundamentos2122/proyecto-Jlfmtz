<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Tamasopo</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">El nombre de este municipio proviene del vocablo huasteco Tamasotpe, pero no se sabe el significado. Anteriormente tuvo su cabecera municipal en un viejo poblado misión del siglo XVI, conocido como San Francisco de la Palma, Tamasopo se convirtió en Villa y adquirió auge al localizarse ahí la vía del ferrocarril San Luis Potosí-Tamasopo.

</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Extensos pantanales como La Ciénega de Tampasquín y La Laguna Grande. Puente de Dios, socavón ahogado por un arroyo cristalino del cual se forman tres cascadas muy atractivas con caídas de 25 metros. Río Trampolín en la Delegación de Agua Buena. Paisajes bellísimos como:  El Pozo Ancho y Las Adjuntas, lugar donde se unen los ríos Tamasopo y Agua Buena
<br>

        </div>
        <div class="col-6">
            <img src="https://visitasanluispotosi.com/en/wp-content/uploads/2019/06/slp-nota-tamasopo-1.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>