<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Catorce</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">La historia del municipio comienza a contarse en el siglo XVIII tiempo en que se le conoce como "Paraje de los alamillos," en 1772 se le da el nombre de "Real de Nuestra Señora de la Concepción de Guadalupe de Álamos," para el año 1779 se cambia el nombre por "Real de la Purísima Concepción de Catorce" y ya hecha la Independencia, solamente "Catorce"
</p>
           
            <p class="jsutify-content mt-3">Las fiestas populares se presentan del 1º al 10 de octubre y se lleva a cabo la festividad en honor a San Francisco de Asís y Danza de los Chichimecas.
Se tiene como tradición el Viacrucis de Semana Santa, fiesta Patronal de San Francisco de Asís, feria, procesiones, música y bailes.
Como atracción turística se encuentra: El propio municipio, que es un auténtico rincón de pueblo colonial, El Cañón de San Bartolomé, Grutas, como Jaquis y La Alberca, Mirador, Cañada de los Catorce.

<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://www.gob.mx/cms/uploads/image/file/512697/RealdeCatorce-RicardoIrak-web.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14613.089787002435!2d-100.92236568128463!3d23.701962901616916!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8680b45c589bc0b5%3A0xff4c5b4450f92720!2s78560%20Los%20Catorce%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177029289!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>