
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fundamentos2122.github.io/framework-css-Jlfmtz/css/framework.css">
    <link rel="stylesheet" href="../css/styles.css">
    <title>Document</title>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/maphilight/1.4.2/jquery.maphilight.min.js"></script>
    <script>
        jQuery(function(){
            jQuery('#mapaSlp').maphilight();
        });
    </script>
</head>
<body>
    <div class="header">
        <nav class="navbar">
            <a href="" class="navbar-brand">BELELMA</a>
            <button class="navbar-toggle" type="button">
                -
            </button>
            
            <div class="navbar-collapse">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="../index.php" class="nav-link">
                            Inicio
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="estado.php" class="nav-link">
                            Estado
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="rutas.php" class="nav-link">
                            Rutas
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="login.php" class="nav-link">
                            Iniciar Sesión
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>