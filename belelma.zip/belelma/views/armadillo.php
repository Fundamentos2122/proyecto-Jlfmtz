<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Armadillo de los Infante</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">El pueblo antiguamente llevó el nombre de "Valle de la Visitación de María Santísima a Santa Isabel de los Armadillos", y por decreto N° 141 del 6 de mayo de 1951 se le llamó oficialmente Armadillo de los Infante.
Tal denominación es en honor de la familia Infante, ya que fueron los primeros impresores en el lugar, mucho antes de que la imprenta fuera establecida en la ciudad de San Luis Potosí.
</p>
           
            <p class="jsutify-content mt-3">Armadillo es un lugar típico y atractivo, de calles empedradas, jardincillos floreados y una hermosa parroquia.
Como atractivos turísticos se tiene: Templo de Pozo del Carmen, posee valiosas pinturas, un altar mayor de retablo barroco sobredecorado y una bonita imagen de la Virgen del Carmen, Imagen de la Purísima Concepción, se encuentra en el altar mayor del templo del mismo nombre, Carrera pedestre del poblado de Xoconostle a la cabecera municipal. En cuyo trayecto se atraviesa la serranía llamada El Carnero.  Esta carrera es ya conocida a nivel nacional.
<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://upload.wikimedia.org/wikipedia/commons/1/10/Templo_de_La_Virgen_del_Carmen.jpg" alt="" class="img-fluid">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14771.43277711464!2d-100.66544328174858!3d22.245458526336837!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x842aaaf2d4a35b11%3A0x754be12495060e39!2s78980%20Armadillo%20de%20los%20Infante%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639176885181!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>