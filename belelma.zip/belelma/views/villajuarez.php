<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Villa Juárez</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">El territorio donde ahora se encuentra asentado el municipio de Villa Juárez en la época prehispánica estuvo habitado primeramente por los huastecos el cual desapareció cuando se desploma la cultura huasteca en el siglo X de la era cristiana.
El segundo grupo de aborígenes que ocupo este territorio fue el de los chichimecas.
En el año de 1643 fue fundada como congregación con el nombre de Santa Gertrudis de Carbonera tiempo después en el año de 1829 se le da la categoría de Villa por decreto Núm. 46 de fecha 26 de septiembre. Posteriormente el gobernador general Saturnino Cedillo en el año de 1928 suprime oficialmente el nombre de Carbonera por el de Villa Juárez honrando de esta manera al Benemérito don Benito Juárez.


</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: En el ejido de Guascamá encontramos una presa de almacenamiento y restos de la Hacienda con su trapiche hidráulico y su antigua fábrica mezcalera. Tiene un acueducto con arcos que traían el agua desde el manantial de Buenavista. Las minas de azufre de Guascamá. Los manantiales: Ojo de León y Sabino. El río Choy.
 


<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://i.pinimg.com/564x/02/63/9b/02639ba56496f5d959a4c72b0c2cd110.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29525.855614794116!2d-100.28472996652557!3d22.32597500861054!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d5638d3f984e0b%3A0x7d6139d7c1e1cd!2sVilla%20Ju%C3%A1rez%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639178296270!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>