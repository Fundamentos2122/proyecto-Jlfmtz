<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Mexquitic de Carmona</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">La palabra Mexquitic es de raíces nahuas o aztecas y quiere decir "lugar de mezquites", lo inexplicable es el porque se le dio ese nombre, pues antes de su fundación no existieron allí indios nahuas. Lo cierto es que fue fundado por fray Diego de la Magdalena en 1583 y lo habitaban  chichimecas. En el año de 1947 la Legislatura del Estado, en su decreto 120 ordena que se le denominara "Mexquitic de Carmona", en honor de su hijo mas afamado el soldado Damián Carmona.

</p>
           
            <p class="jsutify-content mt-3">El mayor atractivo del municipio es su propio pueblo, por su historia y su iglesia, viejo convento edificado por los Franciscanos, con todos los rasgos característicos de las construcciones del siglo XVI. Presa Álvaro Obregón, La Sauceda en el fondo del arroyo, con su pequeño puente es el lugar más pintoresco, La Iglesia, donde es notable el retablo de madera sobredorada del altar, Presa de La Tapona, Presa de Santa Genoveva, Ex Hacienda de Valle Umbroso. El municipio cuenta con un Zoológico, que es un refugio para algunas de las especies animales que se encuentran en peligro de extinción.




<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://www.astrolabio.com.mx/wp-content/uploads/2015/09/110.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14768.982177144799!2d-101.12687168174143!3d22.268686672848574!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x868027a754f001d3%3A0x97d84f4005b00095!2sMexquitic%20de%20Carmona%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177849841!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>