<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Soledad de Graciano Sánchez</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">El sitio donde ahora se asienta la ciudad de Soledad de Graciano Sánchez era conocido desde la antigüedad con el nombre de "Los Ranchos", y los primitivos de ese lugar construyeron una ermita para venerar a la Virgen de la Soledad. Debido a esto se le llamó después "Paraje y Puesto de los Ranchos de Nuestra Señora de la Soledad", esto fue por el año 1758. Con fecha 8 de noviembre de 1827 se conoce ya como "Villa de la Soledad". El general Carlos Diez Gutiérrez promovió para que el nombre de Villa de la Soledad se cambiara por "Soledad Diez Gutiérrez" en el decreto Núm. 2 del 23 de septiembre de 1885, nombre que se conservó más de un siglo. Posteriormente el Congreso del Estado dictó su decreto del 18 de diciembre de 1988 por el cual se le cambió el nombre a este municipio por el de "Soledad de Graciano Sánchez" honrando así la memoria del nativo de este lugar quien se distinguió por su constante lucha, toda su vida, en favor de la clase campesina de todo el país.

</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Construcción de la Ex hacienda Santa Ana, Laguna Seca y La Tinaja. Presa La Joya. Presa Cándido Navarro.
<br>

        </div>
        <div class="col-6">
            <img src="http://www.iglesiapotosina.org/backend-edit/wp-content/uploads/2016/01/nstra-s.-de-soledad.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>