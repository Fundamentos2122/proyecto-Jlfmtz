<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Zaragoza</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">Antiguamente este territorio estuvo habitado por los indígenas llamados chichimecas, los cuales no dejaron ningún testimonio de su presencia en la región.
El capitán Gabriel Ortiz de Fuenmayor fue propietario de extensas tierras entre las que destaca la hacienda la Sauceda la cual estaba dentro del territorio de lo que ahora es Zaragoza, pero su fundador fue don Pedro Arizmendi Gogorrón en el año de 1610.
Entre los años de 1800-1803 se conoce como nuevo dueño de la Sauceda a don José de la Serna. En el año de 1842 el Ayuntamiento de la ciudad adquirió la hacienda.
Durante los años sesenta se le cambia el nombre por San José de la Carrera. Lo de Carrera se debe a que pasaban por el lugar las diligencias que hacían el transporte de pasajeros.
Finalmente por decreto Nº 79 promulgado el 3 de Noviembre de 1882 por el gobernador Pedro Diez Gutiérrez, se erige en cabecera municipal, la población de San José de la Carrera, bajo el nombre de Zaragoza en honor al General mexicano don Ignacio Zaragoza.


</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Ex Hacienda de La Sauceda, con una fábrica de mezcal y una ermita dedicada a San Antonio. En la sierra de Álvarez existe una sima, probablemente de las más profundas, la cual es conocida como El Cárcamo de San Francisco, donde un pequeño arroyo desaparece en una inmensa oquedad de 5 metros de diámetro por cientos de metros de profundidad. Valle de Los Fantasmas. Parque Natural La Parroquia.
 


<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://photo620x400.mnstatic.com/64775616a2662524f58d7892a659d1b8/zaragoza-slp.jpg?quality=70&format=pjpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14793.109892941588!2d-100.7426236318116!3d22.038978907208193!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x842ab1cafa7797d3%3A0xdebeb71a5b09c9!2sVilla%20de%20Zaragoza%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639178228805!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>