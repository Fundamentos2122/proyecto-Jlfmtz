<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Huehuetlán</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">Huehuetlán de raíces aztecas significa "Huehue" = viejo y "Tlán"= lugar, es decir lugar de los viejos, sin embargo algunos autores opinan que Huehuetlán significa "Lugar de tambores", porque la palabra Huehuetl en nahua, es el nombre de los primitivos tambores de madera que usaban los indios. Cabe decir que para los Huastecos ese pueblo en su idioma (huasteco) lo denominaban TAMAHAB. Las fiestas populares se presentan del 12 al 13 de noviembre y se lleva a cabo la festividad en honor de San Diego de Alcalá, iniciándose un novenario y peregrinación de todas las comunidades.

</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Cañada de Tecomón, Pico de la Silleta, Cueva de los Cuatro Vientos, prodigio geológico de la sierra Potosina, Villa de Huehuetlán, cabecera del municipio escondida en la Sierra de Piaxtla, Iglesia de Santiago de Ayala, Río Moctezuma, Arroyo de Huichihuayán, nace en una caverna al pie de la sierra, el sitio se llama El Nacimiento.


<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://scontent.fslp1-1.fna.fbcdn.net/v/t1.18169-9/22894204_1160990790710932_2358323684405542742_n.jpg?_nc_cat=107&ccb=1-5&_nc_sid=09cbfe&_nc_eui2=AeGIoLSuun07g02FNPqPcjdgyWzQCRYCOETJbNAJFgI4RIOwftFynrmxtgT9TNOj2H7J1DbB5voH-vFQPoKDJ8Od&_nc_ohc=l2iuveZiwh4AX98Zsa5&_nc_oc=AQlHL9iAvJaOTXX_AuehtX7jw6OJL-yJ39FOAWirxhySrGBrc78d3jndgSfvh2Ai-mw&_nc_ht=scontent.fslp1-1.fna&oh=c24c4e571982aefea23e1c47a38d25b2&oe=61D8CDC9">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14843.99233630172!2d-98.97592268195925!3d21.546930229782404!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d68ed54785c517%3A0xf2d94972ab73e0f1!2sHuehuetl%C3%A1n%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177652817!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
</div>

<?php include("footer.php"); ?>