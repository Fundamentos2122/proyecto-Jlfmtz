<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Matehuala</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">El municipio fue fundado por D. Cayetano Medellín el 10 de Junio de 1550. Se refiere que el vocablo indígena "MA-TE-HUA-LLAL", era el grito de guerra de los indios salvajes de la región y querían decir ¡no vengan!. En el año de 1778 se le da la categoría de Villa y finalmente en el año de 1826 se le denomina municipio.

</p>
           
            <p class="jsutify-content mt-3">Fiesta del Cristo de Matehuala, del 1º al 15 de enero; el 13 de junio fiesta a San Antonio; del 8 al 16 de julio, conmemoración de la fundación de Matehuala y del 1º al 6 de enero, fiesta tradicional de Reyes.
Artículos de cuero y dulces regionales, flores de papel y tela, jaulas de carrizo, objeto s de ixtle, sombrerías y jarciería.




<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://pulsosanluisrm.blob.core.windows.net.optimalcdn.com/images/2019/07/29/celebrasu22aniversario-focus-0-0-696-423.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d116946.35093077227!2d-100.70841546877489!3d23.65544161101795!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x867e1d86694082f9%3A0x4016978679cc460!2sMatehuala%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177745210!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>