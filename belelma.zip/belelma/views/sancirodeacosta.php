<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita San Ciro de Acosta</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">La tradición dice que los vecinos fundadores de la colonia militar asentada en la hoy cabecera municipal eligieron como Patrono a San Ciro porque el jefe de la colonia era el general José Ciro, la Villa se provee de agua de 3 albercas por lo que al lugar se le conocía como San Ciro de las Albercas.
A fines del año 1910 la plaza de San Ciro fue ocupada por el cabecilla Pedro Montoya, que con esta acción se dio a conocer como rebelde al gobierno porfirista, por esta situación el municipio cambia de nombre al de Villa Pedro Montoya. En otro hecho de armas el revolucionario Miguel Acosta  libera a los presos por lo que actualmente el municipio ahora se llama San Ciro de Acosta en honor del revolucionario.




</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Valle de San Ciro, que está cerrado por el antiguo volcán San Rafael, a cuya erupción se debe la fantástica fertilidad de estas tierras y la formación de una verdadera presa natural al cerrarse la cuenca natural de esa cañada. Ruinas Arqueológicas, como las de:  La Soledad, llamadas La Ciudad Muerta de la Sierra Gorda, las de San Francisco, La Pitahaya y La Laguna. Parroquia de San Ciro. Río de Los Salineros o de Los Vaqueros.
<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://www.frontalnoticias.com/wp-content/uploads/2019/02/DC5C369F-1260-4F61-B031-B0516F1802C5.jpeg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29666.960750554485!2d-99.838388367349!3d21.649456021067632!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d5abfa084f73df%3A0xf00ca974bce0ad76!2sSan%20Ciro%20de%20Acosta%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639178144966!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>