<?php include("header.php"); ?>

<div class="container">
    <h2 class="text-center mt-3">¡Conoce San Luis Potosí!</h2>
    <div class="text-center img-hr"></div>
    <p class="my-3">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Minima, nulla omnis quidem voluptatibus quisquam quaerat ad consequatur. Nulla ab saepe blanditiis sint mollitia quos aspernatur tenetur sunt? Asperiores, officia possimus?</p>

    <div class="row">
        <div class="col-6 col-lg-3 mb-3">
            <div onclick="muestra_oculta('altiplano');" class="zonas">
                <img src="../img/altiplano.png" class="img-fluid card">
                <h4 class="titulo-zona px-3">Zona Altiplano</h4>
            

                <ul class="lista-mun mt-2 px-3 py-2" id="altiplano">
                    <li>
                        <a href="catorce.php">Catorce</a>
                    </li>
                    <li>
                        <a href="cedral.php">Cedral</a>
                    </li>
                    <li>
                        <a href="charcas.php">Charcas</a>
                    </li>
                    <li>
                        <a href="guadalcazar.php">Guadalcázar</a>
                    </li>
                    <li>
                        <a href="matehuala.php">Matehuala</a>
                    </li>
                    <li>
                        <a href="salinas.php">Salinas</a>
                    </li>
                    <li>
                        <a href="santodomingo.php">Santo Domingo</a>
                    </li>
                    <li>
                        <a href="vanegas.php">Vanegas</a>
                    </li>
                    <li>
                        <a href="venado.php">Venado</a>
                    </li>
                    <li>
                        <a href="villadearista.php">Villa de Arista</a>
                    </li>
                    <li>
                        <a href="villadeguadalupe.php">Villa de Guadalupe</a>
                    </li>                  
                    <li>
                        <a href="villahidalgo.php">Villa Hidalgo</a>
                    </li>
                    <li>
                        <a href="villadelapaz.php">Villa de la Paz</a>
                    </li>
                    <li>
                        <a href="villaderamos.php">Villa de Ramos</a>
                    </li> 
                </ul>
            </div>
        </div>
        <div class="col-6 col-lg-3 mb-3">
            <div onclick="muestra_oculta('centro');" class="zonas">
                <img src="../img/altiplano.png" class="img-fluid card">
                <h4 class="titulo-zona px-3">Zona Centro</h4>
            

                <ul class="lista-mun mt-2 px-3 py-2" id="centro">
                    <li><a href="ahualulco.php">Ahualulco</a></li>
                    <li><a href="armadillo.php">Armadillo de los Infante</a></li>
                    <li><a href="cerrodesanpedro.php">Cerro de San Pedro</a></li>
                    <li><a href="mexquitic.php">Mexquitic de Carmona</a></li>
                    <li><a href="sanluispotosi.php">San Luis Potosí</a></li>
                    <li><a href="santamaria.php">Santa María del Río</a></li>
                    <li><a href="soledad.php">Soledad de Graciano Sánchez</a></li>
                    <li><a href="tierranueva.php">Tierranueva</a></li>
                    <li><a href="villadearriaga.php">Villa de Arriaga</a></li>
                    <li><a href="villadereyes.php">Villa de Reyes</a></li>                   
                    <li><a href="zaragoza.php">Zaragoza</a></li>
                </ul>
            </div>
        </div>
        <div class="col-6 col-lg-3 mb-3">
            <div onclick="muestra_oculta('media');" class="zonas">
                <img src="../img/altiplano.png" class="img-fluid card">
                <h4 class="titulo-zona px-3">Zona Media</h4>
            

                <ul class="lista-mun mt-2 px-3 py-2" id="media">
                    <li><a href="alaquines.php">Alaquines </a></li>
                    <li><a href="cardenas.php">Cárdenas </a></li>
                    <li><a href="cerritos.php">Cerritos </a></li>
                    <li><a href="ciudaddelmaiz.php">Ciudad del Maíz </a></li>
                    <li><a href="ciudadfernandez.php">Ciudad Fernández </a></li>
                    <li><a href="lagunillas.php">Lagunillas </a></li>
                    <li><a href="rayon.php">Rayón </a></li>
                    <li><a href="rioverde.php">Rioverde </a></li>
                    <li><a href="sancirodeacosta.php">San Ciro de Acosta </a></li>
                    <li><a href="santacatarina.php">Santa Catarina </a></li> 
                    <li><a href="villajuarez.php">Villa Juárez </a></li>
                    <li><a href="sannicolas.php">San Nicolás Tolentino </a></li>
                </ul>
            </div>
        </div>
        <div class="col-6 col-lg-3 mb-3">
            <div onclick="muestra_oculta('huasteca');" class="zonas">
                <img src="../img/altiplano.png" class="img-fluid card">
                <h4 class="titulo-zona px-3">Zona Huasteca</h4>

                <ul class="lista-mun mt-2 px-3 py-2" id="huasteca">
                    <li>    
                        <a href="aquismon.php">
                            Aquismón
                        </a>
                    </li>
                    <li>
                        <a href="axtla.php">
                            Axtla de Terrazas
                        </a>
                    </li>
                    <li>
                        <a href="ciudadvalles.php">
                            Ciudad Valles
                        </a>
                    </li>
                    <li>
                        <a href="coxcatlan.php">
                            Coxcatlán
                        </a>
                    </li>
                    <li>
                        <a href="ebano.php">
                            Ebano
                        </a>
                    </li>
                    <li>
                        <a href="elnaranjo.php">
                            El Naranjo
                        </a>
                    </li>
                    <li>
                        <a href="huehuetlan.php">
                            Huehuetlán
                        </a>
                    </li>
                    <li>
                        <a href="matlapa.php">
                            Matlapa
                        </a>
                    </li>
                    <li>
                        <a href="sanantonio.php">
                            San Antonio
                        </a>
                    </li>
                    <li>
                        <a href="sanmartin.php">
                            San Martín Chalchicuautla 
                        </a>
                    </li>                  
                    <li>
                        <a href="sanvicente.php">
                            San Vicente Tancuayalab
                        </a>
                    </li>
                    <li>
                        <a href="tamasopo.php">
                            Tamasopo
                        </a>
                    </li>
                    <li>
                        <a href="tamazunchale.php">
                            Tamazunchale
                        </a>
                    </li>
                    <li>
                        <a href="tampacan.php">
                            Tampacán
                        </a>
                    </li>
                    <li>
                        <a href="tampamolon.php">
                            Tampamolón Corona
                        </a>
                    </li>
                    <li>
                        <a href="tamuin.php">
                            Tamuín
                        </a>
                    </li>
                    <li>
                        <a href="tancanhuitz.php">
                            Tancanhuitz de Santos
                        </a>
                    </li>
                    <li>
                        <a href="tanquian.php">
                            Tanquián de Escobedo
                        </a>
                    </li>
                    <li>
                        <a href="xilitla.php">
                            Xilitla
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>   
</div>

<?php include("footer.php"); ?>
