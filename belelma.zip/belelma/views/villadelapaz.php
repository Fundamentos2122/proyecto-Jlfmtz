<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Villa de la Paz</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">El puesto de la Boca, se le llamó así a este lugar por el siglo XVIII ya que algunas familias de gambusinas se establecieron allí buscando mineral, se le denominaba puesto, pues así se designaba a los lugares de población más o menos transitorio, que no tenían autoridad ni gobierno alguno; posteriormente la Boca se transforma en Hacienda de Beneficio.
En la década de 1870 se comenzó a explotar la primera mina del mineral de la Paz, por lo que la actividad minera se fue acrecentando, por el nombre de esta mina se conoció así a este centro mineral y después a todo el municipio. 


</p>
           
            <p class="jsutify-content mt-3">Las fiestas populares se presentan del 16 al 24 de enero y se lleva a cabo la festividad en honor a la Virgen de La Paz, con feria regional. Como atracción turística se encuentra: Cerro del Fraile, en el que existen vestigios arqueológicos. Antigua Hacienda La Boca. Iglesia de dos torres en honor a la Virgen de La Paz. Zonas minerales, conocidas como "Tiros de Mina".


<br>

        </div>
        <div class="col-6">
            <img src="https://www.turimexico.com/wp-content/uploads/2015/06/villadelapaz.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>