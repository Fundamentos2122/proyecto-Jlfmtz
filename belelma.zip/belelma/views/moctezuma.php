<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Moctezuma</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">La fecha más antigua de su fundación data del año 1552 y se le denominaba "San Jerónimo del Agua Hedionda". El 19 de julio de 1826 en el artículo 9º del decreto Núm.46 se le denomina simplemente "hedionda", y con categoría de Municipio.
Por decreto dictado el 1º de enero de 1868 se ordenó que la "Ciudad de la Hedionda" se denominara en lo sucesivo "Ciudad Moctezuma". Esto para honrar al general Esteban Moctezuma, que por cierto no nació ahí sino en el rancho de Tortugas perteneciente al municipio de Alaquines.


</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Ex Hacienda Ganadera San Antonio de Rul, con una casa señorial de fachada neoclásica y un hermoso e intacto patio con arquería y Ex Hacienda de Cruces, con un manantial de agua tibia.




<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://scontent.fslp1-1.fna.fbcdn.net/v/t1.6435-9/180132965_103993171848971_473381791301130024_n.jpg?_nc_cat=109&ccb=1-5&_nc_sid=09cbfe&_nc_eui2=AeEXlkuq5DhqA72aFSfJwXhy6GIOJEvAovroYg4kS8Ci-oUWOYFJhsuSOil8-2aOCM3balkTHPF4Lol_YVkOpNOw&_nc_ohc=0f_rPa-X3l8AX9NojEc&tn=aEkqfZzvAaeNwh40&_nc_ht=scontent.fslp1-1.fna&oh=00_AT8Ou_bV0PiF60PSUqaVQAnL8A1IYQF6X5IpC0FsgOxPYQ&oe=61D7E8E7">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29435.156488958146!2d-101.10051951599381!3d22.750734172654283!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x868044709a81e6a5%3A0xc557fcbe384661be!2s78900%20Moctezuma%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177893376!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>