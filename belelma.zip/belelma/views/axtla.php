<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Axtla de Terrazas</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-12">
            <p class="jsutify-content">Del siglo XVI sólo se tiene el dato que la palabra Axtla deriva del mexicano, Aztlán, que equivale al lugar de las garzas y que era encomienda, a fines del siglo XVI, de Diego de Torres Maldonado. Por otras fuentes se sabe que Axtla tiene ese nombre debido a que estando a orillas de una gran corriente de agua (el río de su nombre, formado por el Huichihuayán y el Tancuilín en Matlapa), la abundancia de aves acuáticas de esa clase dio lugar a ese nombre. El nombre de Terrazas le fue aumentado para honrar al revolucionario Alfredo M. Terrazas.



</p>
           
            <p class="jsutify-content mt-3">Las fiestas populares se presentan el 25 de noviembre, celebrándose la festividad en honor a Santa Catarina e inicio de la víspera.  Exhibición de Danzas como Los Matlachines, El Zopilote, Las Varitas y el Palo Volador. Como atracción turística se encuentra el río Tamancillo, que atraviesa por uno de los costados al municipio. 
 


<br>

        </div>
        <div class="col-12 col-lg-12">
            <img src="https://www.estilodf.tv/wp-content/uploads/2021/01/1240-x-720-9-1-768x432.png">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14855.120070475601!2d-98.88183703199142!3d21.43788994567528!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d68d766da1c4cb%3A0xdf88d0eae31c0965!2sAxtla%20de%20Terrazas%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639176950999!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>