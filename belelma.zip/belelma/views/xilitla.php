<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Xilitla</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">Este nombre es de raíces indígenas del habla náhuatl o mexicano, Xilitla es un pueblo antiguo llamado anteriormente Taziol. El historiador Joaquín Meade publicó dos distintas raíces de esta palabra: Xilitla "del Mexicano cili-tlán, lugar de caracolillos". Y años después nos ofrece otra interpretación: Xilitla "de Xali-tlán, entre la arena de o Cilitlán, entre los caracolillos".
Sin embargo, el historiador don Joaquín García Icazbalceta, en su obra póstuma Vocabulario del Mexicanismo, publicada por su hijo Don Luis García Pimentel nos explica que la palabra Xilitla deriva del nahua y que en esa lengua caracol se escribe Tequizhulcats y que Tlán sí es lugar de. Y que Xilitla es Chili-tlán, cuya equivalencia es: Chili= a chile y tlán=a lugar de.
Por lo que en Mexicano quiere decir "Lugar de chile".

</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: La Silleta, un macizo montañoso que es todo un reto para los montañistas. En el límite con el estado de Querétaro, existen bosques de enormes pinos y en esta ruta se encuentra un parador llamado "El Paraíso", desde donde se aprecia el profundo Cañón de Tancuilín y una hermosa vista de la sierra. Ahuacatlán, que es un pintoresco pueblo que merece ser visitado. Grutas de Xilitla, donde se encuentran pinturas rupestres sobre el origen de los huastecos.  Se encuentran al sur de la población de Xilitla. El municipio es famoso por su café y su producción de piloncillo, además de ser el lugar más lluvioso de San Luis Potosí. Mansión de Sir Eduard. Sótano de Tlamaya. Cueva El Salitre.
 


<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://www.gob.mx/cms/uploads/article/main_image/84694/San-Luis-Potosi_Xilitla_Las-Pozas-web-.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14860.45829244087!2d-99.00107513200687!3d21.38539290330223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d69a7e19a3aa51%3A0x6c2fed44d67ca439!2s79900%20Xilitla%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639178261624!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>