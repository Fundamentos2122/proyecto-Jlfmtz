<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Guadalcázar</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">La palabra Guadalcázar es de raíces árabes: Guada=Río y Alcázar=Fortaleza. En el año de 1608 se le dio el título de "Villa y Minas de San Pedro", posteriormente en el año de 1616 se le denomina "Real de Guadalcázar", en honor del Virrey que en ese tiempo gobernaba. Las fiestas populares se presentan del 16 al 25 de diciembre y se lleva a cabo la festividad en honor a la navidad. Se tiene como tradición del 22 al 25 de diciembre la Feria Popular.

</p>
           
            <p class="jsutify-content mt-3">Como atracción turística cuenta con: Gruta de San Cayetano, la cual tiene forma de elipse de 100 y 180 metros de ejes.  Sus estalactitas y estalagmitas adoptan formas caprichosas, en el fondo hay una fuente de agua dulce, Gruta de Los Candiles, Gruta de Guadalupe, Cerro de las Piedras, que tiene raros monolitos, Los Arcos, formación rocosa a manera de portal que con el sol produce coloraciones inusitadas.


<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://gtmimg.com/IMG_SERVER/GTM.mx_170211031415.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d17519.082823211986!2d-100.40712974143659!3d22.618958853072215!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x867fe85418410073%3A0x6c978442116dcad4!2sGuadalc%C3%A1zar%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177614914!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>