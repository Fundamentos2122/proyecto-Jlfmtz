<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Villa de Arista</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-6">
            <p class="jsutify-content">De acuerdo con los escritos de los religiosos del siglo XVI en la época prehispánica la región que hoy ocupa el municipio de Villa de Arista fue habitado por los errantes guachichiles. En el año de 1711 don Juan Zeferino denunció la propiedad de un terreno al cual teniendo ya en posesión lo denomino como el "Jagüey", posteriormente don Antonio Reyna junto con sus 10 hijos tomaron posesión cambiándole el nombre como "El Jagüey de los Reyna". El 12 de octubre de 1897 se erigió en Villa con el nombre del presidente Mariano Arista y finalmente en el año de 1972 se crea el municipio de "Villa de Arista".


</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra la parroquia con torre y cúpula de gran belleza, la cual constituye el orgullo de los lugareños.
 


<br>

        </div>
        <div class="col-6">
            <img src="https://i.pinimg.com/564x/55/11/b0/5511b0e350632c879c147d9e052907bd.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29510.220954276163!2d-101.1841089197782!3d22.399739357393205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86802ff497649bf7%3A0xc54da9b13fa69633!2s78450%20Ahualulco%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639108147471!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>