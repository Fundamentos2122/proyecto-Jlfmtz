<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Ciudad del Maíz</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">El municipio de Ciudad del Maíz fue fundado el 15 de julio de 1617 por fray Juan Bautista Mollinedo con el nombre de "Custodia de Santa Catarina Virgen y Mártir". En el Siglo XVIII, esta región se hallaba convertida en hacienda y en 1749 cuando se mandó repoblar con otra colonia de indios pames, se le llamó "La Purísima Concepción del Valle del Maíz" y ya se encontraba habitada por varias familias de españoles. Las fiestas populares se presentan del 12 al 20 de enero, celebrándose la feria regional.
</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Parroquia con su atrio arbolado y un altar neoclásico en relieve y estucado en oro, Laguna de patos, Laguna Agua Zarca, Manantiales del Sabinito, Las Abritas, El Porvenir, y el de Los Perales.



<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="http://www.ciudadsanluis.com/turismo/articulos/valle_del_maiz/ciudad_del_maiz.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14754.89044969738!2d-99.61504218170035!3d22.401812202796446!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d58a8215ea109d%3A0x1c5077289750097b!2sCd%20del%20Ma%C3%ADz%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177451151!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>