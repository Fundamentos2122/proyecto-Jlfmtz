<?php include("header.php"); ?>

<div class="container">
    <div class="mt-5">
        <div class="row">
            <div class="col-6">
                <img src="https://visitasanluispotosi.com/wp-content/uploads/2019/06/slp-nota-feria-nacional-potosina-fenapo-10.jpg" alt="" class="img-fluid card">
            </div>
            <div class="col-6">
                <h3 class="my-4">Feria Nacional Potosina</h3>
                <p class="text-justify mb-3">La Feria Nacional Potosina (FENAPO) es uno de los eventos más importantes del estado, se planea con muchos meses de anticipación y se realiza en el Recinto Ferial de la capital durante el verano.</p>
                <hr>
                <p class="text-justify mt-3">Sobresalen las exposiciones agroalimentaria y ganadera, las escaramuzas, el rodeo, las corridas de toros, el palenque de gallos, el espectáculo de los voladores de Papantla y, por supuesto, los juegos mecánicos.</p>
            </div>
        </div>
    </div>

    <div class="mt-5">
        <div class="row">
            <div class="col-6">
                <img src="https://visitasanluispotosi.com/wp-content/uploads/2019/01/slp-nota-xantolo-1.jpg" alt="" class="img-fluid card">
            </div>
            <div class="col-6">
                <h3 class="my-4">Xantolo</h3>
                <p class="text-justify mb-3">es una de las celebraciones más importantes de la Huasteca Potosina, las festividades de días de muertos en las cabeceras municipales se viven entre risas, aguardiente y comida.</p>
                <hr>
                <p class="text-justify mt-3">Recorriendo panteones, probando la gastronomía típica de esta temporada, oliendo inciensos y flores, la experiencia es única para los visitantes.</p>
            </div>
        </div>
    </div>

    <div class="mt-5">
        <div class="row">
            <div class="col-6">
                <img src="https://visitasanluispotosi.com/wp-content/uploads/2020/04/SLP3-2.jpg" alt="" class="img-fluid card">
            </div>
            <div class="col-6">
                <h3 class="my-4">Museos</h3>
                <p class="text-justify mb-3">Recorre alguno de los mejores museos del estado.</p>
                <hr>
                <p class="text-justify mt-3">Durante estos días que nos invitan a quedarnos en casa, San Luis Potosí nos ofrece actividades virtuales en algunos museos a través de la aplicación Google Maps, así que relájate ponte cómodo y disfruta de cada uno de estos museos y #QuédateEnCasa.</p>
            </div>
        </div>
    </div>
    
</div>

<?php include("footer.php"); ?>