<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Cedral</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">La historia comienza para Cedral en 1726, cuando el cronista Franciscano Fr. José Arlegui lo refiere como una simple "Hacienda Vaquera", y en 1795 tiene el nombre de "Santa María de la Asunción del Cedral" impuesto por frailes franciscanos. Y finalmente, en el año de 1826 tiene ya la categoría de municipio con el nombre de "Cedral". Las fiestas populares se presentan del 31 de julio al 15 de agosto y se lleva a cabo la festividad en honor de la Virgen de la Asunción, acompañada de corridas de toros, carreras de caballos, palenque, peleas de gallo y baile.
</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: La ciudad, que está trazada con calles anchas, rectas, bordeadas de frondosos fresnos y nogales, Balneario La Estancia, que se localiza en el rancho del mismo nombre, ubicado sobre la carretera Matehuala-Saltillo.

<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://i2.wp.com/www.turimexico.com/wp-content/uploads/2015/06/cedral.jpg?fit=640%2C404&ssl=1">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29200.193140860672!2d-100.74114181460801!3d23.817740522480968!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86875384a4c7c979%3A0xf5c3a1aea611b58f!2sCedral%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177065168!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>