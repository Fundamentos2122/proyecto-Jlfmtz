</body>

<div class="bg-banner mt-5"></div>
<footer class="bg-dark">
    <div class="container">
        <div class="row">
            <div class="col-4">
                <h3 class="mt-2 text-light">Belelma</h3>
            </div>

            <div class="col-4 text-center">
                <p class="mt-5 text-light">Derechos Reservados 2021</p>
            </div>

            <div class="col-4">
                <img src="" alt="">
            </div>
        </div>
    </div>
</footer>
<script src="https://fundamentos2122.github.io/framework-css-Jlfmtz/js/framework.js"></script>
<script src="../js/belelma.js"></script>
</html>