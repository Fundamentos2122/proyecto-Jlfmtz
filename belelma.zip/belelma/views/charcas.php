<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Charcas</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">El nombre de  "Santa María de las Charcas" que los españoles impusieron al mineral fue en honor de la "Virgen María"  y  "Charcas" es en referencia a la región minera que se encuentra al norte de Sucre en Bolivia. Esta región llegó a ser una intendencia muy importante pues su jurisdicción abarcó una parte del norte de Argentina y otra de Uruguay, destacándose esta región por su riqueza.
Finalmente en el periódico oficial del estado Nº 2,257 de fecha 22 de abril de 1928 se publicó el decreto Nº 61 dictado por el Congreso del Estado, promulgado el 12 de abril de 1928 por medio del cual se confirma la categoría política de "Ciudad"  para Charcas, municipio del mismo nombre.

</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Parroquia de San Francisco de Asís, donde se venera a la Virgen de Charcas. Esta imagen tiene un pedestal de plata, labrado en complicado y hermoso trabajo de orfebrería. Fábrica de artículos de ónix. Centro Recreativo Ojo de Agua. Antigua Alhóndiga. Monumento a Cristo Rey, conocido como La Cruz del Siglo. Zona paleontológica. Grutas de la Cueva Azul.

<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://scontent.fslp1-1.fna.fbcdn.net/v/t1.18169-9/13427768_1211787925512718_4131186748006820453_n.jpg?_nc_cat=101&ccb=1-5&_nc_sid=e3f864&_nc_eui2=AeGWb65gG3mj0SKXTm0AkS8PMZ34omau3F4xnfiiZq7cXu7HKW6N3vFOdartt-GANOmQDjQNO9p4TOSOkv0hKbVc&_nc_ohc=zB0Rji-E3F0AX_mJyb6&_nc_ht=scontent.fslp1-1.fna&oh=1cd62548839c658777e90e26439499e2&oe=61DA7C88">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29353.09681278325!2d-101.13346746551113!3d23.128663400034696!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8680f100fa7d2b47%3A0xb5bc74feebb49360!2sCharcas%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177273500!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>