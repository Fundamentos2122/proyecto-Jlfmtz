<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Villa Hidalgo</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">Al norte de lo que es hoy la cabecera municipal se encuentra un jagüey cuyo dueño era Ambrosio Martínez, por tal motivo a este lugar se le denominaba "El Jagüey de Ambrosio Martínez". Este lugar se fue poblando y dio origen al poblado llamado "San José de los Picachos", debido  a que en sus alrededores hay conos, cráteres y xalapazcos (volcanes que nacen y mueren).
Teniendo categoría de congregación, sus habitantes, solicitaron que se elevara de categoría política, por lo que pasó a ser fracción del municipio de la capital, llamándosele oficialmente fracción del tanquecito seguramente le fue impuesto en razón del Jagüey casi inmediato al pueblo.
Esta fracción del tanquecito fue elevada a la categoría de municipio en el año de 1857 con el nombre de Villa Hidalgo para honrar al Padre de la Patria; nombre que poco duro pues a fines de ese mismo año fue cambiado por el de Villa Iturbide, el cual ostento por largos años.
Fue en el año de 1928 que la Legislatura local, dictó su decreto por medio del cual se ordenó cambiar de nombre a este municipio y cabecera, que en lo sucesivo debía llamarse Villa Hidalgo.

</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: La antigua hacienda de Peotillos cuyo casco se conserva. La casa de los Carmelitas Las trojes. La antigua hacienda de la Tapona con una noria antigua abovedada. En las cercanías del cráter conocido como la Joya existen unas cuevas donde esta el famoso molde del "Equus Potosino" y fósiles de plantas.
 


<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://scontent.fslp1-1.fna.fbcdn.net/v/t39.30808-6/s960x960/252705872_119571100505061_6878525373493282503_n.jpg?_nc_cat=104&ccb=1-5&_nc_sid=e3f864&_nc_eui2=AeEsDegbQPo22-MjFMKdtYl5B-fKOmQYK0gH58o6ZBgrSI6P9FL4g7lTA3ENru6Tabobx640hn1IeACTglOQaGom&_nc_ohc=Bq0jkSUyubUAX-h9wep&_nc_ht=scontent.fslp1-1.fna&oh=00_AT_BYsic8DFVKM88e4un0xmAy3ogyC1r7QzMCwwswEm6jQ&oe=61B77BFA">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29498.568855626363!2d-100.6963456163658!3d22.454564467659843!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86800617cafc9c85%3A0xbc40fc03894e559e!2sVilla%20Hidalgo%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639178333468!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>