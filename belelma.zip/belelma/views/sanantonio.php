<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita San Antonio</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">Este lugar habitado por indígenas Teneek se conocía como Tlaxicali de Tamhanentzen, al crecer el número de habitantes trataron de obtener licencia para fundar un pueblo con la advocación de San Antonio de Padua, por lo que posteriormente a este lugar se le conocía como San Antonio de Tamhanentzen, con el paso de los años quedó simplemente con el nombre de San Antonio.



</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Su Iglesia, con torres muy alta y su plaza techa. Se cuenta una misteriosa leyenda acerca de una iglesia perdida, que según se narra, fue fundada por los primeros pobladores y que tiene una campana encantada que suena los viernes santos.
<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://sanluispotosi.quadratin.com.mx/www/wp-content/uploads/2020/10/6870f9b4-9bb8-4c12-96a1-82fe92e78ac7.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7418.252318833213!2d-98.90678842803794!3d21.62000706679335!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d661e0465db871%3A0x64ff3843c29413dc!2sSan%20Antonio%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639178109713!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>