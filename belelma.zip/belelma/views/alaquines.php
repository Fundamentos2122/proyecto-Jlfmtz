<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Alaquines</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">Se deriva del nombre de la tribu indígena de los Alaquines la cual fue acasillada en este lugar en 1616.</p>
            <p class="jsutify-content mt-3">Las fiestas populares se presentan el 25 de julio, celebrándose la festividad en honor del señor Santiago.</p>
            <p class="jsutify-content mt-3">Como atracción turística se encuentra:
La famosa escultura guatemalteca del siglo XVIII, llamada "El Santo Entierro", la cual consiste en un Cristo de tamaño normal que se colocó en una urna, Presa Obregón, Las haciendas de Martínez y San José de Palmas, Colonia indígena pame que se enecuentra a un kilómetro de la cabecera municipal.
<br>
        </div>
        <div class="col-12 col-lg-6">
            <img src="https://i2.wp.com/www.turimexico.com/wp-content/uploads/2015/06/alaquines.jpg?fit=800%2C600&ssl=1" alt="" class="img-fluid">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14784.123468138116!2d-99.60404503178553!3d22.124798794406903!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d5926e992aa6e7%3A0xaa94178b99706393!2sAlaquines%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639176763812!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>