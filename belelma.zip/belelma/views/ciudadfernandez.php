<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Ciudad Fernández</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">El nombre actual del municipio es en honor del general Zenón Fernández, nativo del lugar. Del 1o a114 de enero se celebra la fiesta religiosa del Dulce Nombre de Jesús, el 26 de junio al 4 de julio se celebra la fiesta popular del Refugio. 
</p>
           
            <p class="jsutify-content mt-3">Dentro de la variedad de platillos encontramos: Birria, Barbacoa de Borrego, Tamales de Barbacoa, cecina, guiso borracho, tamales, mole rojo, nopales, garbanzos, Enchiladas, chorizo y carnitas.

Dulces Típicos. De piloncillo, calabaza y biznaga.




<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://www.elsoldesanluis.com.mx/incoming/tmce6t-ciudad-fernandez/alternates/LANDSCAPE_400/Ciudad%20Fern%C3%A1ndez">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d59214.606353436895!2d-100.0661629977604!3d21.937899758681446!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d5732a240e49a1%3A0xe42c9e2b58d2d756!2sCd%20Fern%C3%A1ndez%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177413557!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>