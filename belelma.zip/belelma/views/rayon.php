<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Rayón</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">Había en el sur del actual municipio de Rayón una antigua misión franciscana fundada en 1617 por Fr. Juan Bautista Mollinedo y Fr. Juan de Cárdenas y se le llamaba "San Felipe de los Gamotes". En el año de 1827 el 8 de octubre por decreto número 61 artículo 26, se le declara Ayuntamiento a la Villa de Nuevo Gamotes. 
Posteriormente la Legislatura del Estado dicto su decreto número 26 promulgado el 14 de diciembre de 1857 y ordeno: En lo sucesivo la Villa de Nuevo Gamotes llevará el nombre de Villa Rayón en memoria del héroe de la Independencia don Ignacio López Rayón quien nació o vivió en esa jurisdicción.

</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Parroquia, construcción sólida de piedra y volcánica del lugar, con fachada estilo neoclásico, Cascada La Llovizna, atractivo natural que se forma en un precipicio de piedra, de fuertes corrientes que caen en forma estrepitosa sobre el despeñadero, transformándose en montones de espuma, que al levantarse se convierte en arcoíris, Ruinas Arqueológicas.

<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://scontent.fslp1-1.fna.fbcdn.net/v/t1.18169-9/189739_101480576599812_1291668_n.jpg?_nc_cat=106&ccb=1-5&_nc_sid=09cbfe&_nc_eui2=AeHekoJ6PxPNo5oARtX_bbOfn8siiZmAzEOfyyKJmYDMQ8wC6JccLXC6Dk_xSSg-UCnjtfi_HdCJFpQaobrY5QHI&_nc_ohc=eZoQOI-3-HkAX-ZeI4s&_nc_ht=scontent.fslp1-1.fna&oh=512d5e360d363a30e6ca984400798683&oe=61D875FB">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29626.52737553599!2d-99.66471621711356!3d21.84534661006692!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d5bbefa40a8c3d%3A0x4187d6497d8248b!2s79740%20Ray%C3%B3n%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177965512!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>