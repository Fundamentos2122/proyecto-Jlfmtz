<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Ciudad Valles</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">El pueblo de "Santiago de los Valles" fue fundado en el año de 1533 por Nuño de Guzmán, este lo llevó a cabo con 25 vecinos y el primer encomendero al que encargó el gobierno del mismo fue Francisco Barrón.
La Legislatura del Estado en su decreto No. 60 del 5 de octubre de 1827, ordenó que todas las cabeceras de Departamento y Partido se denominarían Ciudades. Por ello desde esa fecha, la antigua Villa de los Valles, se convirtió en Ciudad Valles.

</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Balneario de aguas termales "El Bañito", que recibe numerosos visitantes que llegan en casas móviles.  Existe un hotel cercano, con excelentes instalaciones para los aficionados al golf. Cascada de Micos, que consiste en una serie de caídas de agua con estacionamientos de gran belleza natural.  Se localiza a 18 kilómetros de Ciudad Valles el segmento del río Tampaón que es conocido como el río Micos y está encajonado por montes tupidos de vegetación. Zona Arqueológica Tampuxeque a 40 kilómetros al norte de Ciudad Valles, en donde existe una plazoleta y un gran cué en forma de L, que mide aproximadamente 60x55 metros y 3 metros de altura. Museo Regional  Huasteco de Antropología y Arqueología.
<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://www.zonaturistica.com/files/atractivos/1898/A1_1898.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d118382.76446105329!2d-99.08553955335877!3d21.993625560356783!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d612aa8cfda92f%3A0x3338605912bc2688!2sCd%20Valles%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177360931!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>