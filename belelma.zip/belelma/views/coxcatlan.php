<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Coxcatlán</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">La palabra Coxcatlán es azteca y significa "cuenta, o collar o gargantilla, piedra preciosa". En idioma huasteco es "Tansicab", cuyas raíces son lugar escondido. Finalmente nos refieren que Coxcatlán equivale a "Ayotochcuitlatán", palabra también azteca y nos dicen que es "donde abunda excremento de armadillo".
</p>
           
            <p class="jsutify-content mt-3">Celebran su festividad el 24 de junio, que es la fiesta religiosa popular en honor a San Juan Bautista, iniciándose un novenario y peregrinación  en todas las comunidades.
Las principales artesanías que se fabrican en el municipio son ollas de barro y canastas de bejuco.

<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://mapio.net/images-p/84581608.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29689.67402816199!2d-98.9223908174811!3d21.538671705378718!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d68ecd1604ab5f%3A0x7bc27ef866dc838c!2sCoxcatl%C3%A1n%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177489744!5m2!1ses-419!2smx" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    
</div>

<?php include("footer.php"); ?>