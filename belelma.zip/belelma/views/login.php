<?php
    //Verificar al usuario
    session_start();

    if (array_key_exists("mail", $_SESSION)) {
        header("Location: http://localhost/belelma/belal/");
        exit();
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fundamentos2122.github.io/framework-css-Jlfmtz/css/framework.css">
    <link rel="stylesheet" href="../css/styles.css">
    <title>Document</title>
</head>
<body>
    <div class="head-log">
        <a href="index.php">
            <h3>BELELMA</h3>
        </a>
    </div>

    <div class="bg-dark login">
        <h2 class="text-center text-light pt-2">Belal</h2>
        <h5 class="text-center text-light">Inicio de Sesión</h5>

        <div class="container">
            <form action="../controllers/loginController.php" method="POST" class="text-center mt-4 px-5">
                <input type="hidden" name="_method" value="POST">
                <?php
                    if(array_key_exists("error", $_GET)){
                        echo '<div class="alert alert-danger show">' . $_GET["error"] .'</div>';
                    }
                ?>
                <input type="email" name="mail" placeholder="Correo electrónico">
                <input type="password" name="pass" placeholder="Contraseña" class="mt-4">
                
                <div class="form-group text-center mt-3">
                    <input type="submit" value="Ingresar" class="btn btn-block btn-info">
                </div>
            </form>
        </div>
        <div class="text-center py-3">
            <a href="signup.php" class="link-registro">¿No tienes cuenta?</a>
        </div>
        
        
    </div>
</body>
</html>