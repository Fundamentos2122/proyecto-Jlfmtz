<?php include("header.php"); ?>
<h1 class="encabezado text-left py-4 px-2 text-light">Visita Cerritos</h1>

<div class="container">
    <div class="row py-4">
        <div class="col-12 col-lg-6">
            <p class="jsutify-content">En la época colonial se le conoció con el nombre de "Rancho de San Juan de los Cerritos", en 1826 recibe el título de "Villa de Cerritos" y en el año de 1830 adquiere categoría política de municipio hasta la fecha. Su cabecera municipal se encuentra ubicada en una explanada entre pequeños cerros. Las fiestas populares se presentan del 16 al 24 de junio y se lleva a cabo la festividad en honor de San Juan Bautista.
</p>
           
            <p class="jsutify-content mt-3">Como atracción turística se encuentra: Iglesia de San Juan Bautista y Santuario en el cerro de la Cruz. 

<br>

        </div>
        <div class="col-12 col-lg-6">
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/10/Panor%C3%A1mica_de_Cerritos_%28cropped%29.jpg/800px-Panor%C3%A1mica_de_Cerritos_%28cropped%29.jpg">
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29503.695290415948!2d-100.30124191639582!3d22.43045937535014!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x867ff318e90ae497%3A0xc05d7d20610bc6f9!2sCerritos%2C%20S.L.P.!5e0!3m2!1ses-419!2smx!4v1639177163550!5m2!1ses-419!2smx" width="1005" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
</div>

<?php include("footer.php"); ?>