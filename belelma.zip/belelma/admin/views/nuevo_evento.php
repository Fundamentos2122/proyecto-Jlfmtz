<?php include("header.php") ?>

<div class="container">    
    <h4 class="border-bottom py-2">Agregar evento</h4>
    <form action="../controllers/eventosController.php" method="post" class="row" autocomplete="off" enctype="multipart/form-data">
        <input type="hidden" name="_method" value="POST">
        <div class="col-6 form-group">
            <label for="nombre_evento">Nombre del evento:</label>
            <input type="text" name="nombre_evento" class="form-control" required>
        </div>
        <div class="col-6 form-group">
            <label for="foto">Foto</label>
            <input type="file" name="foto" class="form-control" required>
        </div>
        <div class="col-12 form-group">
            <label for="url_evento">Url:</label>
            <input type="text" name="url_evento" class="form-control" required>
        </div>
        <div class="col-12 form-group text-center">
            <input type="submit" value="Guardar" class="btn btn-success">
            <a href="index.php" class="btn btn-secondary">Cancelar</a>
        </div>
    </form>
</div>

<?php include("footer.php"); ?>