<?php include("header.php") ?>

<div class="container">    
    <h4 class="border-bottom py-2">Agregar paquete</h4>
    <form action="../controllers/paquetesController.php" method="post" class="row" autocomplete="off" enctype="multipart/form-data">
        <input type="hidden" name="_method" value="POST">
        <div class="col-12 form-group">
            <label for="nombre_paquete">Nombre del paquete:</label>
            <input type="text" name="nombre_paquete" class="form-control" required>
        </div>
        <div class="col-6 form-group">
            <label for="huespedes">Huespedes:</label>
            <input type="number" name="huespedes" class="form-control" required>
        </div>
        <div class="col-6 form-group">
            <label for="habitaciones">Habitaciones:</label>
            <input type="number" name="habitaciones" class="form-control" required>
        </div>
        <div class="col-7 form-group">
            <label for="detalles">Detalles:</label>
            <input type="text" name="detalles" class="form-control" required>
        </div>
        <div class="col-5 form-group">
            <label for="precio">Precio:</label required>
            <div class="row">
                <div class="col-7">
                    <input type="number" name="precio" class="form-control" required>
                </div>
                <div class="col-5">
                    <label for="">/noche</label>
                </div>
            </div>
        </div>
        <div class="col-12 form-group">
            <label for="foto">Foto:</label>
            <input type="file" name="foto" class="form-control">
        </div>
        <div class="col-12 form-group text-center">
            <input type="submit" value="Guardar" class="btn btn-success">
            <a href="index.php" class="btn btn-secondary">Cancelar</a>
        </div>
    </form>
</div>

<?php include("footer.php"); ?>