<?php include("header.php") ?>

<div class="container">

    <div class="row border-bottom pt-2">
        <div class="col-8">
            <h4>Editar evento</h4>
        </div>
        <div class="col-4">
            <div class="text-right">
                <form id="form_delete" action="../controllers/eventosController.php" method="post">
                    <input type="hidden" name="_method" value="DELETE">
                    <input type="submit" value="Eliminar" class="btn btn-danger">
                </form>
            </div>
        </div>
    </div>

    <div class="pt-3">
        <form id="form_put" action="../controllers/eventosController.php" method="post" class="row" autocomplete="off" enctype="multipart/form-data">
            <input type="hidden" name="_method" value="PUT">
            <div class="col-12 form-group">
                <label for="nombre_evento">Nombre del paquete:</label>
                <input type="text" name="nombre_evento" class="form-control" id="nombre_evento">
            </div>
            <div class="col-12 form-group">
                <label for="foto">Foto:</label>
                <input type="file" name="foto" class="form-control">
            </div>
            <div class="col-12 form-group">
                <label for="url_evento">Url:</label>
                <input type="text" name="url_evento" class="form-control" id="url_evento">
            </div>
            <div class="col-12 form-group text-center">
                <input type="submit" value="Guardar" class="btn btn-success">
                <a href="eventos.php" class="btn btn-secondary">Cancelar</a>
            </div>
        </form>
    </div>
    
</div>


    <script>
        const formPut = document.getElementById("form_put");
        const formDelete = document.getElementById("form_delete");

        const input_nombreEvento = document.getElementById("nombre_evento");
        const input_urlEvento = document.getElementById("url_evento");

        const id_evento = "" + <?php echo $_GET["id"] ?> + "";

        getEvento();

        function getEvento() {
            var xhttp = new XMLHttpRequest();

            xhttp.open("GET", "../controllers/eventosController.php?id=" + id_evento, false);
        
            xhttp.onreadystatechange = function() {
                if(this.readyState == 4) {
                    var evento = JSON.parse(this.responseText);

                    formPut.action += "?id=" + evento.id;
                    formDelete.action += "?id=" + evento.id;
                    
                    input_nombreEvento.value = evento.nombre_evento;
                    input_urlEvento.value = evento.url_evento;
    

                }
            };

            xhttp.send();
        }
    </script>