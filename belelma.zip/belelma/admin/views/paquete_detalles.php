<?php include("header.php") ?>

<div class="container">

    <div class="row border-bottom pt-2">
        <div class="col-8">
            <h4>Editar paquete</h4>
        </div>
        <div class="col-4">
            <div class="text-right">
                <form id="form_delete" action="../controllers/paquetesController.php" method="post">
                    <input type="hidden" name="_method" value="DELETE">
                    <input type="submit" value="Eliminar" class="btn btn-danger">
                </form>
            </div>
        </div>
    </div>

    <div class="pt-3">
        <form id="form_put" action="../controllers/paquetesController.php" method="post" class="row" autocomplete="off" enctype="multipart/form-data">
            <input type="hidden" name="_method" value="PUT">
            <div class="col-12 form-group">
                <label for="nombre_paquete">Nombre del paquete:</label>
                <input type="text" name="nombre_paquete" class="form-control" id="nombre_paquete">
            </div>
            <div class="col-6 form-group">
                <label for="huespedes">Huespedes:</label>
                <input type="number" name="huespedes" class="form-control" id="huespedes">
            </div>
            <div class="col-6 form-group">
                <label for="habitaciones">Habitaciones:</label>
                <input type="number" name="habitaciones" class="form-control" id="habitaciones">
            </div>
            <div class="col-7 form-group">
                <label for="detalles">Detalles:</label>
                <input type="text" name="detalles" class="form-control" id="detalles">
            </div>
            <div class="col-5 form-group">
                <label for="precio">Precio:</label>
                <div class="row">
                    <div class="col-7">
                        <input type="number" name="precio" class="form-control" id="precio">
                    </div>
                    <div class="col-5">
                        <label for="">/noche</label>
                    </div>
                </div>
            </div>
            <div class="col-12 form-group">
                <label for="foto">Foto:</label>
                <input type="file" name="foto" class="form-control">
            </div>
            <div class="col-12 form-group text-center">
                <input type="submit" value="Guardar" class="btn btn-success">
                <a href="paquetes.php" class="btn btn-secondary">Cancelar</a>
            </div>
        </form>
    </div>
    
</div>


    <script>
        const formPut = document.getElementById("form_put");
        const formDelete = document.getElementById("form_delete");
        const input_nombrePaquete = document.getElementById("nombre_paquete");
        const input_huespedes = document.getElementById("huespedes");
        const input_habitaciones = document.getElementById("habitaciones");
        const input_detalles = document.getElementById("detalles");
        const input_precio = document.getElementById("precio");

        const id_paquete = "" + <?php echo $_GET["id"] ?> + "";

        getPaquete();

        function getPaquete() {
            var xhttp = new XMLHttpRequest();

            xhttp.open("GET", "../controllers/paquetesController.php?id=" + id_paquete, false);
        
            xhttp.onreadystatechange = function() {
                if(this.readyState == 4) {
                    var paquete = JSON.parse(this.responseText);

                    formPut.action += "?id=" + paquete.id;
                    formDelete.action += "?id=" + paquete.id;
                    
                    input_nombrePaquete.value = paquete.nombre_paquete;
                    input_huespedes.value = paquete.huespedes;
                    input_habitaciones.value = paquete.habitaciones;
                    input_detalles.value = paquete.detalles;
                    input_precio.value = paquete.precio;

                }
            };

            xhttp.send();
        }
    </script>