<?php include("header.php"); ?>
<div class="container">
        <h1 class="py-4">Bienvenido</h1>
    </div>

<?php include("footer.php"); ?>