<?php include("header.php"); ?>
    <div class="bg-secondary py-3">
        <div class="row px-4">
            <div class="col-6">
                <h3>Paquetes Turísticos</h3>
            </div>
            <div class="col-6 text-right">
            <a href="nuevo_paquete.php" class="btn btn-primary">Nuevo</a>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row py-3 secciones-admin">
            <?php
                include("../controllers/paquetesController.php");
            ?>
            
            <!--<div class="col-3">
                <img src="https:\\picsum.photos\1000\1000" class="img-fluid card">
                <p>Jose Luis Martinez</p>
            </div>-->
        </div>
    </div>

<?php include("footer.php"); ?>