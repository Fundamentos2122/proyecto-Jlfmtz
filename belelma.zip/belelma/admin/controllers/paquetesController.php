<?php

include("../models/DB.php");
include("../models/Paquete.php");

try {
    $connection = DBConnection::getConnection();
}
catch(PDOException $e) {
    error_log("Error de conexion - " . $e, 0);
    header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    //Leer
    if (array_key_exists("id", $_GET)) {
        //Traer la información de un elemento        
        $id = $_GET["id"];

        try {
            $query = $connection->prepare("SELECT * FROM paquetes WHERE id = :id");
            $query->bindParam(":id", $id, PDO::PARAM_INT);
            $query->execute();

            while($row = $query->fetch(PDO::FETCH_ASSOC)) {
                $paquete = new Paquete($row["id"], $row["nombre_paquete"], $row["huespedes"], $row["habitaciones"], $row["detalles"], $row["precio"], $row["foto"]);

                $paquete->returnJson();
            }
        }
        catch(PDOException $e) {
            error_log("Error en query - " . $e, 0);
            header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
            exit();
        }
    }
    else {
        //Traer el listado de todos los registros
        try {
            $query = $connection->prepare("SELECT * FROM paquetes");
            $query->execute();

            while($row = $query->fetch(PDO::FETCH_ASSOC)) {
                $paquete = new Paquete($row["id"], $row["nombre_paquete"], $row["huespedes"], $row["habitaciones"], $row["detalles"], $row["precio"], $row["foto"]);

                echo 
                    "<div class='col-3'>".
                        "<a href='paquete_detalles.php?id=" . $paquete->getId() . "'>".
                            "<img src=\"data:image/jpeg;base64," . $paquete->getFoto() . "\" class='img-fluid card'>".
                            "<h4 class='text-center'>" . $paquete->getNombrePaquete() . "</h4>".
                            "<p class='justify-content'>" . $paquete->getHuespedes() . " Huespedes, " . $paquete->getHabitaciones() . " Habitaciones</p>" . 
                            "<p class='justify-content'>" . $paquete->getDetalles() . "</p>" . 
                            "<h5 class='text-right'> $" . $paquete->getPrecio() . " /noche</h5>" .
                        "</a>".
                    "</div>";
            }
        }
        catch(PDOException $e) {
            error_log("Error en query - " . $e, 0);
            header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
            exit();
        }
    }
}
elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($_POST["_method"] == "POST") {
        //Guardar
        $nombre_paquete = $_POST["nombre_paquete"];
        $huespedes = $_POST["huespedes"];
        $habitaciones = $_POST["habitaciones"];
        $detalles = $_POST["detalles"];
        $precio = $_POST["precio"];
        $foto = "";

        if(sizeof($_FILES) > 0) {
            $tmp_name = $_FILES["foto"]["tmp_name"];
            $foto = file_get_contents($tmp_name);
        }

        try {
            $query = $connection->prepare('INSERT INTO paquetes VALUES(NULL, :nombre_paquete, :huespedes, :habitaciones, :detalles, :precio, :foto)');
            $query->bindParam(':nombre_paquete', $nombre_paquete, PDO::PARAM_STR);
            $query->bindParam(':huespedes', $huespedes, PDO::PARAM_INT);
            $query->bindParam(':habitaciones', $habitaciones, PDO::PARAM_INT);
            $query->bindParam(':detalles', $detalles, PDO::PARAM_STR);
            $query->bindParam(':precio', $precio, PDO::PARAM_STR);
            $query->bindParam(':foto', $foto, PDO::PARAM_STR);
            $query->execute();

            if ($query->rowCount() == 0) {
                //Error
                header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
                exit();
            }

            header("Location: http://localhost/belelma/admin/views/paquetes.php");
        }
        catch(PDOException $e) {
            error_log("Error en query - " . $e, 0);
            header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
            exit();
        }
    }
    else if ($_POST["_method"] == "PUT") {
        //Actualizar
        $id = $_GET["id"];
        $nombre_paquete = $_POST["nombre_paquete"];
        $huespedes = $_POST["huespedes"];
        $habitaciones = $_POST["habitaciones"];
        $detalles = $_POST["detalles"];
        $precio = $_POST["precio"];
        $foto = "";

        $update_foto = false;

        if(sizeof($_FILES) > 0 && $_FILES["foto"]["tmp_name"] !== "") {
            $tmp_name = $_FILES["foto"]["tmp_name"];
            $foto = file_get_contents($tmp_name);
            $update_foto = true;
        }
        
        try {
            $query_string = 'UPDATE paquetes SET nombre_paquete = :nombre_paquete, huespedes = :huespedes, habitaciones = :habitaciones, detalles = :detalles, precio = :precio';

            if($update_foto === true) {
                $query_string = $query_string . ', foto = :foto';
            }

            $query = $connection->prepare($query_string . ' WHERE id = :id');
            $query->bindParam(':id', $id, PDO::PARAM_INT);
            $query->bindParam(':nombre_paquete', $nombre_paquete, PDO::PARAM_STR);
            $query->bindParam(':huespedes', $huespedes, PDO::PARAM_INT);
            $query->bindParam(':habitaciones', $habitaciones, PDO::PARAM_INT);
            $query->bindParam(':detalles', $detalles, PDO::PARAM_STR);
            $query->bindParam(':precio', $precio, PDO::PARAM_STR);

            if($update_foto === true) {
                $query->bindParam(':foto', $foto, PDO::PARAM_STR);
            }
            $query->execute();

            if ($query->rowCount() == 0) {
                //Error
                header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
                exit();
            }

            header("Location: http://localhost/belelma/admin/views/paquetes.php");
        }

        catch(PDOException $e) {
            error_log("Error en query - " . $e, 0);
            header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
            exit();
        }
    }
    else if ($_POST["_method"] == "DELETE") {
        //Eliminar
        $id = $_GET["id"];

        try {
            $query = $connection->prepare('DELETE FROM paquetes WHERE id = :id');
            $query->bindParam(':id', $id, PDO::PARAM_INT);
            $query->execute();

            if ($query->rowCount() == 0) {
                //Error
                header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
                exit();
            }

            header("Location: http://localhost/belelma/admin/views/paquetes.php");
        }
        
        catch(PDOException $e) {
            error_log("Error en query - " . $e, 0);
            header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
            exit();
        }        
    }
    else {
        //Error
    }
}

?>