<?php

include("../models/DB.php");
include("../models/Evento.php");

try {
    $connection = DBConnection::getConnection();
}
catch(PDOException $e) {
    error_log("Error de conexion - " . $e, 0);
    header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    //Leer
    if (array_key_exists("id", $_GET)) {
        //Traer la información de un elemento        
        $id = $_GET["id"];

        try {
            $query = $connection->prepare("SELECT * FROM eventos WHERE id = :id");
            $query->bindParam(":id", $id, PDO::PARAM_INT);
            $query->execute();

            while($row = $query->fetch(PDO::FETCH_ASSOC)) {
                $evento = new Evento($row["id"], $row["nombre_evento"], $row["foto"], $row["url_evento"]);

                $evento->returnJson();
            }
        }
        catch(PDOException $e) {
            error_log("Error en query - " . $e, 0);
            header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
            exit();
        }
    }
    else {
        //Traer el listado de todos los registros
        try {
            $query = $connection->prepare("SELECT * FROM eventos");
            $query->execute();

            while($row = $query->fetch(PDO::FETCH_ASSOC)) {
                $evento = new Evento($row["id"], $row["nombre_evento"], $row["foto"], $row["url_evento"]);

                echo 
                    "<div class='col-4'>".
                        "<a href='evento_detalles.php?id=" . $evento->getId() . "'>".
                            "<img src=\"data:image/jpeg;base64," . $evento->getFoto() . "\" class='img-fluid card'>".
                            "<p class='text-center'>" . $evento->getNombreEvento() . "</p>".
                        "</a>".
                    "</div>";
            }
        }
        catch(PDOException $e) {
            error_log("Error en query - " . $e, 0);
            header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
            exit();
        }
    }
}
elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($_POST["_method"] == "POST") {
        //Guardar
        $nombre_evento = $_POST["nombre_evento"];
        $foto = "";
        $url_evento = $_POST["url_evento"];

        if(sizeof($_FILES) > 0) {
            $tmp_name = $_FILES["foto"]["tmp_name"];
            $foto = file_get_contents($tmp_name);
        }

        try {
            $query = $connection->prepare('INSERT INTO eventos VALUES(NULL, :nombre_evento, :foto, :url_evento)');
            $query->bindParam(':nombre_evento', $nombre_evento, PDO::PARAM_STR);
            $query->bindParam(':foto', $foto, PDO::PARAM_STR);
            $query->bindParam(':url_evento', $url_evento, PDO::PARAM_STR);
            $query->execute();

            if ($query->rowCount() == 0) {
                //Error

                exit();
            }

            header("Location: http://localhost/belelma/admin/views/eventos.php");
        }
        catch(PDOException $e) {
            error_log("Error en query - " . $e, 0);

            exit();
        }
    }
    else if ($_POST["_method"] == "PUT") {
        //Actualizar
        $id = $_GET["id"];
        $nombre_evento = $_POST["nombre_evento"];
        $foto = "";
        $url_evento = $_POST["url_evento"];

        $update_foto = false;

        if(sizeof($_FILES) > 0 && $_FILES["foto"]["tmp_name"] !== "") {
            $tmp_name = $_FILES["foto"]["tmp_name"];
            $foto = file_get_contents($tmp_name);
            $update_foto = true;
        }
        
        try {
            $query_string = 'UPDATE eventos SET nombre_evento = :nombre_evento, url_evento = :url_evento';

            if($update_foto === true) {
                $query_string = $query_string . ', foto = :foto';
            }

            $query = $connection->prepare($query_string . ' WHERE id = :id');
            $query->bindParam(':id', $id, PDO::PARAM_INT);
            $query->bindParam(':nombre_evento', $nombre_evento, PDO::PARAM_STR);
            $query->bindParam(':url_evento', $url_evento, PDO::PARAM_STR);

            if($update_foto === true) {
                $query->bindParam(':foto', $foto, PDO::PARAM_STR);
            }
            $query->execute();

            if ($query->rowCount() == 0) {
                //Error

                exit();
            }

            header("Location: http://localhost/belelma/admin/views/eventos.php");
        }

        catch(PDOException $e) {
            error_log("Error en query - " . $e, 0);
            header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
            exit();
        }
    }
    else if ($_POST["_method"] == "DELETE") {
        //Eliminar
        $id = $_GET["id"];

        try {
            $query = $connection->prepare('DELETE FROM eventos WHERE id = :id');
            $query->bindParam(':id', $id, PDO::PARAM_INT);
            $query->execute();

            if ($query->rowCount() == 0) {
                //Error
                header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
                exit();
            }

            header("Location: http://localhost/belelma/admin/views/eventos.php");
        }

        catch(PDOException $e) {
            error_log("Error en query - " . $e, 0);
            header("Location: http://localhost/belelma/views/error.php?error=Error de conexión a la base de datos.");
            exit();
        }
    }
    else {
        //Error
    }
}

?>