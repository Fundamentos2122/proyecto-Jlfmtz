<?php
    //Redireccionar a la página principal
    header("Location: views/");
?>