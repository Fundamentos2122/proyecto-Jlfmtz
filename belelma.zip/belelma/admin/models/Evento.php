<?php

class Evento {
    private $_id;
    private $_nombre_evento;
    private $_foto;
    private $_url_evento;

    public function __construct($id, $nombre_evento, $foto, $url_evento) {
        $this->setId($id);
        $this->setNombreEvento($nombre_evento);
        $this->setFoto($foto);
        $this->setUrlEvento($url_evento);
    }

    public function getId() {
        return $this->_id;
    }

    public function setId($id) {
        $this->_id = $id;
    }

    public function getNombreEvento() {
        return $this->_nombre_evento;
    }

    public function setNombreEvento($nombre_evento) {
        $this->_nombre_evento = $nombre_evento;
    }

    public function getFoto() {
        return $this->_foto;
    }

    public function setFoto($foto) {
        $this->_foto = base64_encode($foto);
    }

    public function getUrlEvento() {
        return $this->_url_evento;
    }

    public function setUrlEvento($url_evento) {
        $this->_url_evento = $url_evento;
    }

    public function returnJson() {
        $evento = array();

        $evento["id"] = $this->getId();
        $evento["nombre_evento"] = $this->getNombreEvento();
        $evento["foto"] = $this->getFoto();
        $evento["url_evento"] = $this->getUrlEvento();

        echo json_encode($evento);
    }
    
}

?>