<?php

class Paquete {
    private $_id;
    private $_nombre_paquete;
    private $_huespedes;
    private $_habitaciones;
    private $_detalles;
    private $_precio;
    private $_foto;
    

    public function __construct($id, $nombre_paquete, $huespedes, $habitaciones, $detalles, $precio, $foto) {
        $this->setId($id);
        $this->setNombrePaquete($nombre_paquete);
        $this->setHuespedes($huespedes);
        $this->setHabitaciones($habitaciones);
        $this->setDetalles($detalles);
        $this->setPrecio($precio);
        $this->setFoto($foto);
    }

    public function getId() {
        return $this->_id;
    }

    public function setId($id) {
        $this->_id = $id;
    }

    public function getNombrePaquete() {
        return $this->_nombre_paquete;
    }

    public function setNombrePaquete($nombre_paquete) {
        $this->_nombre_paquete = $nombre_paquete;
    }

    public function getHuespedes() {
        return $this->_huespedes;
    }

    public function setHuespedes($huespedes) {
        $this->_huespedes = $huespedes;
    }

    public function getHabitaciones() {
        return $this->_habitaciones;
    }

    public function setHabitaciones($habitaciones) {
        $this->_habitaciones = $habitaciones;
    }

    public function getDetalles() {
        return $this->_detalles;
    }

    public function setDetalles($detalles) {
        $this->_detalles = $detalles;
    }

    public function getPrecio() {
        return $this->_precio;
    }

    public function setPrecio($precio) {
        $this->_precio = $precio;
    }

    public function getFoto() {
        return $this->_foto;
    }

    public function setFoto($foto) {
        $this->_foto = base64_encode($foto);
    }

    public function returnJson() {
        $paquete = array();

        $paquete["id"] = $this->getId();
        $paquete["nombre_paquete"] = $this->getNombrePaquete();
        $paquete["huespedes"] = $this->getHuespedes();
        $paquete["habitaciones"] = $this->getHabitaciones();
        $paquete["detalles"] = $this->getDetalles();
        $paquete["precio"] = $this->getPrecio();
        $paquete["foto"] = $this->getFoto();

        echo json_encode($paquete);
    }
    
}

?>